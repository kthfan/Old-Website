
#ifndef _BUILD_BAT
#include "build_bat.h"
#endif //_BUILD_BAT

Step1_ArgInfo step1_ArgInfo;
Step2_VarInfo step2_VarInfo;
Step3_FileInfo step3_FileInfo;
char szBatFileBuffer[MAX_BAT_FILE_SIZE];
//char szBatCommandBuffer[MAX_BAT_COMMAND_SIZE];
//int nBatFileBufferPointer;
//int nBatCommandBufferPointer;

VOID buildBatInitialize(){
	step1_ArgInfo = Step1_ArgInfo();
	step2_VarInfo = Step2_VarInfo();
	ZeroMemory(&step1_ArgInfo, sizeof(Step1_ArgInfo));
	ZeroMemory(&step2_VarInfo, sizeof(Step2_VarInfo));
	ZeroMemory(szBatFileBuffer, sizeof(char)*MAX_BAT_FILE_SIZE);
	step1_ArgInfo.argc = 0;
	step1_ArgInfo.argsName = "argv";
	step1_ArgInfo.argcName = "argc";
	step2_VarInfo.batFileBuffer.pointer = 0;
	step2_VarInfo.batFileBuffer.buffer = szBatFileBuffer;
	step2_VarInfo.barCommandBufferLen = 0;
}
VOID buildBatClean(){
	int i,j,len,len2;
	BatStatement* tempStatement;
	free(step1_ArgInfo.argsName);
	free(step1_ArgInfo.argcName);
	freeArray((void**) step1_ArgInfo.argv, step1_ArgInfo.argc);
	//clean step2Statement
	len = step2_VarInfo.step2StatementLen;
	for(i=0;i<len;i++){
		tempStatement = &step2_VarInfo.step2Statement[i];
		free(tempStatement->compiler);
	}
	len = step2_VarInfo.barCommandBufferLen;
	for(i=0;i<len;i++){
		free(step2_VarInfo.batCommandBuffer[i].buffer);
		//free(step2_VarInfo.batCommandBuffer[i]);
	}
	free(step2_VarInfo.isSet);
}
BOOL buildBatStep1(char** lpArgv, char** lpDefArg, int nArgvLen){
	int i;
	step1_ArgInfo.argsName = lpDefArg[0];
	step1_ArgInfo.argcName = lpDefArg[1];
	step1_ArgInfo.argc = nArgvLen;
	step1_ArgInfo.argv = lpArgv;
	return TRUE;
	//return writeBatFileBuffer(BEGIN_BAT_COMMAND) && writeBatFileBuffer(FOR_PARSE_ARGS) && writeBatFileBuffer(SET_PWD_VAR);
}
BOOL buildBatStep2(int statementLen, BatStatement* userStatement){
	//step2_VarInfo.isSet = (int*) malloc(sizeof(int)*step1_ArgInfo.argc);
	//ZeroMemory(step2_VarInfo.isSet,sizeof(int)*step1_ArgInfo.argc);
	step2_VarInfo.serialNum4Var = 0;
	step2_VarInfo.step2Statement = userStatement;
	step2_VarInfo.step2StatementLen = statementLen;
	int i,len;
	BOOL bRes;
	for(i=0;i<statementLen;i++){
		switch(userStatement[i].type){
			case STATEMENT_TYPE_COMPILER:
				bRes = step2_compiler(&userStatement[i]);
				break;
			case STATEMENT_TYPE_PARTFILE:
				bRes = step2_partfile(&userStatement[i]);
				break;
			//case STATEMENT_TYPE_ALTER:
				//didn't consider N_ARG_FILE_NAME | N_ARG_FILE_EXT
				//bRes = step2_alter(&userStatement[i]);
			//	break;
			case STATEMENT_TYPE_DIST:
				break;
			case STATEMENT_TYPE_SPACE:
				bRes = writeBatCommandBuffer(" ");
				break;
			case STATEMENT_TYPE_NEWLINE:
				bRes = writeBatCommandBuffer("\r\n");
				break;
			default:
				return FALSE;
				
		}
		if(!bRes) return FALSE;
	}
	len = step2_VarInfo.barCommandBufferLen;
	for(i=0;i<len;i++){
		bRes &= writeBatFileBuffer(step2_VarInfo.batCommandBuffer[i].buffer);
	}
	return bRes;
}
BOOL buildBatStep3(){
	return writeBatFileBuffer(END_BAT_COMMAND);
}
BOOL buildBatSaveBatFile(){
	HANDLE fileHandle = CreateFile( step3_FileInfo.dist_bat_name, GENERIC_READ | GENERIC_WRITE,
		0, 0, CREATE_ALWAYS, 0, 0 ) ;
	char* szBuffer = step2_VarInfo.batFileBuffer.buffer;
	DWORD len;
	
	if(fileHandle == NULL || fileHandle == INVALID_HANDLE_VALUE )
		return FALSE;
	if(!WriteFile( fileHandle, szBuffer,(DWORD)strlen( szBuffer ) + 1, &len, NULL )){
		CloseHandle( fileHandle );
		return FALSE;
	}
	CloseHandle( fileHandle );
	return TRUE;
}
BOOL step2_compiler(BatStatement* userStatement){
	return writeBatCommandBuffer("\r\n") && writeBatCommandBuffer(userStatement->compiler);
}
BOOL step2_partfile(BatStatement* userStatement){
	BOOL bRes;
	int nArg_th = userStatement->arg_th;
	int nType = userStatement->part_type;
	char* szVarName;
	char* szBatVarName;
	if(!step2_VarInfo.isSet[nArg_th]){	//If var not set. e.g. FOR_PARSE_FILE
		char* szSetVarCommand = getSetFileVarCommand(nArg_th);
		bRes = writeBatFileBuffer(szSetVarCommand);
		free(szSetVarCommand);
		if(!bRes) return FALSE;
		step2_VarInfo.isSet[nArg_th] = TRUE;
	}
	szVarName = getVarName(nArg_th, nType);
	szBatVarName = getBatFormVar(szVarName);
	bRes = writeBatCommandBuffer(szBatVarName);
	free(szBatVarName);
	free(szVarName);
	return bRes;
}

/*Deprecated
BOOL step2_alter(BatStatement* userStatement){
	//didn't consider N_ARG_FILE_NAME | N_ARG_FILE_EXT
	BOOL bRes;
	int nArg_th = userStatement->arg_th;
	int nType = userStatement->part_type;
	char** szAlter = userStatement->file_alter;
	char* szAlterVarName = getAlterVarName(nArg_th, nType);
	char* szBatAlterVarName;
	if(!isElseVarSet(szAlterVarName)){	//If AlterVar not set.
		//var part
		if(!isSet[nArg_th]){
			char* szSetVarCommand = getSetFileVarCommand(nArg_th);
			bRes = writeBatFileBuffer(szSetVarCommand);
			free(szSetVarCommand);
			if(!bRes) return FALSE;
			isSet[nArg_th] = TRUE;
		}
		//alter part
		char* szSetAlterVarCommand = getSetAlterVarCommand(nArg_th, nType, szAlter);
		bRes = writeBatFileBuffer(szSetAlterVarCommand);
		free(szSetVarCommand);
		if(!bRes) return FALSE;
		//didn't set to TRUE
	}else free(szAlterVarName);	//Because of isElseVarSet().
	szAlterVarName = getAlterVarName(nArg_th, nType); 
	szBatAlterVarName = getBatFormVar(szAlterVarName);
	bRes = writeBatCommandBuffer(szBatAlterVarName);
	free(szBatAlterVarName);
	free(szAlterVarName);
	return bRes;
}
*/

BOOL writeBatFileBuffer(char* data){
	char* szBatFileBuffer = step2_VarInfo.batFileBuffer.buffer;
	int nBatFileBufferPointer = step2_VarInfo.batFileBuffer.pointer;
	int len = nBatFileBufferPointer + strlen(data);
	if(len >= MAX_BAT_FILE_SIZE) return FALSE;
	strcpy(szBatFileBuffer+nBatFileBufferPointer,data);
	nBatFileBufferPointer = len;
	return TRUE;
}
BOOL writeBatCommandBuffer(char* data, int index){
	char* szBatCommandBuffer = step2_VarInfo.batCommandBuffer[index].buffer;
	int nBatCommandBufferPointer = step2_VarInfo.batCommandBuffer[index].pointer;
	int len = nBatCommandBufferPointer + strlen(data);
	if(len >= MAX_BAT_COMMAND_SIZE) return FALSE;
	strcpy(szBatCommandBuffer+nBatCommandBufferPointer,data);
	nBatCommandBufferPointer = len;
	return TRUE;
}
BOOL writeBatCommandBuffer(char* data){
	return writeBatCommandBuffer(data, step2_VarInfo.barCommandBufferLen-1);
}
char* getSetFileVarCommand(int nArg_th){
	char* szRes;
	char* szName = getVarName(nArg_th, N_ARG_FILE_NAME);
	char* szPath = getVarName(nArg_th, N_ARG_FILE_PATH);
	char* szExt = getVarName(nArg_th, N_ARG_FILE_EXT);
	int nArgthLen = getIntLen(nArg_th)+1;
	int nResSize;
	nResSize = sizeof(char)*(nArgthLen+strlen(szName)+strlen(szPath)+strlen(szExt)+strlen(FOR_PARSE_FILE)-19+1);
	szRes = (char*) malloc(nResSize);
	
	ZeroMemory(szRes,nResSize);
	sprintf(szRes,FOR_PARSE_FILE,nArg_th,szName,szPath,szExt);
	free(szName);
	free(szPath);
	free(szExt);
	return szRes;
}
/*Deprecated
char* getSetAlterVarCommand(int nArg_th, int nType, char** szAlter){
	//set var_1_alter_ext_2_exe_=%var_1_path%%var_1_name%
	char* szRes;
	char* szAlterVar = getAlterVarName(nArg_th,nType);
	char* szVar4Set[N_ARG_FILE_TYPE_LENGTH] = {0};
	char* szTemp;
	int nResSize;
	int nResLen = 0;
	int i,j,nMask;
	for(i=0,j=0;i<N_ARG_FILE_TYPE_LENGTH;i++){
		nMask = 1<<i;
		if(nType&nMask) {
			szVar4Set[i] = szAlter[j];
			j++;
		}else {
			szTemp = getVarName(nArg_th, nMask);
			szVar4Set[i] = getBatFormVar(szTemp);
			free(szTemp);
		}
		nResLen += strlen(szVar4Set[i]);
	}
	nResLen += strlen(szAlterVar) + 8;
	nResSize = sizeof(char)*nResLen;
	szRes = (char*) malloc(nResSize);
	ZeroMemory(szRes,nResSize);
	sprintf(szRes,"set %s=%s%s%s\r\n",szAlterVar,szVar4Set[0],szVar4Set[1],szVar4Set[2]);
	//free, not include arg szAlter
	for(i=0;i<N_ARG_FILE_TYPE_LENGTH;i++){
		nMask = 1<<i;
		if(nType&nMask) {
		}else free(szVar4Set[i]);
	}
	return szRes;
}
BOOL isElseVarSet(char* szElseVar){
	//This will set into step2_VarInfo.elseVar simultaneously.
	char** szElseVar = step2_VarInfo.elseVar;
	char** szTempElseVar;
	int nElseVarLen = step2_VarInfo.elseVarLen;
	int i;
	for(i=0;i<nElseVarLen;i++){
		if(strcmp(szElseVar[i],szElseVar)==0)
			return TRUE;
	}
	
	szTempElseVar = (char**) malloc(sizeof(char*)*(nElseVarLen+1));
	for(i=0;i<nElseVarLen;i++){
		szTempElseVar[i] = szElseVar[i];
	}
	szTempElseVar[nElseVarLen] = szElseVar;
	nElseVarLen++;
	step2_VarInfo.elseVarLen = nElseVarLen;
	return FALSE;
}

char* getAlterVarName(int nArg_th, int nType){
	//var_1_alter_ext_13_
	char* szRes;
	char* szType[N_ARG_FILE_TYPE_LENGTH] = {SZ_ARG_FILE_NAME,SZ_ARG_FILE_PATH,SZ_ARG_FILE_EXT};
	int n_TypeLen, nArgthLen, nSerialNum4VarLen;
	int nSerialNum4Var = step2_VarInfo.serialNum4Var;
	int nResLen = 0;
	int i,j,nMask;
	for(i=0,j=0;i<N_ARG_FILE_TYPE_LENGTH;i++){
		nMask = 1<<i;
		if(nType&nMask) {
		}else szType[i] ="";
		nResLen += strlen(szType[i]);
	}
	nArgthLen = getIntLen(nArg_th)+1;
	nSerialNum4VarLen = getIntLen(nSerialNum4Var)+1;
	nSerialNum4Var++;
	step2_VarInfo.serialNum4Var = nSerialNum4Var;
	nResLen += nArgthLen + nSerialNum4VarLen + 16;
	nResSize = sizeof(char)*(nResLen);
	szRes = (char*) malloc(nResSize);
	ZeroMemory(szRes,nResSize);
	sprintf(szRes,"var_%i_alter_%s_%s_%s_%i_",nArg_th,szType[0],szType[1],szType[2],nSerialNum4Var);
	return szRes;
}
*/
int getIntLen(int nDigit){
	int nLen = 0;
	while(nDigit>=1){
		nDigit/=10;
		nLen++;
	}
	return nLen;
}
char* getVarName(int nArg_th, int nType){
	char* szRes;
	char* szType = "";
	int n_TypeLen;
	int nArgthLen = 1;
	int nTmp = nArg_th;
	int nResSize;
	switch(nType){
		case N_ARG_FILE_NAME:
			n_TypeLen = strlen(SZ_ARG_FILE_NAME);
			szType = SZ_ARG_FILE_NAME;
			break;
		case N_ARG_FILE_PATH:
			n_TypeLen = strlen(SZ_ARG_FILE_PATH);
			szType = SZ_ARG_FILE_PATH;
			break;
		case N_ARG_FILE_EXT:
			n_TypeLen = strlen(SZ_ARG_FILE_PATH);
			szType = SZ_ARG_FILE_PATH;
			break;
		default:
			break;
	}
	
	nArgthLen = getIntLen(nArg_th)+1;
	
	nResSize = sizeof(char)*(nArgthLen+n_TypeLen+7);
	szRes = (char*) malloc(nResSize);
	ZeroMemory(szRes,nResSize);
	sprintf(szRes,"var_%i_%s_",nArg_th,szType);
	return szRes;
}
char* getBatFormVar(char* szVar){
	//Returns %szVar%, won't free(szVar)
	char* szRes;
	int nResSize;
	nResSize = sizeof(char)*(strlen(szVar)+7);
	szRes = (char*) malloc(nResSize);
	ZeroMemory(szRes,nResSize);
	sprintf(szRes,"%%%s%%",szVar);
	return szRes;
}
char* getBatVarRuler(char* szVar){
	//unuse
}

