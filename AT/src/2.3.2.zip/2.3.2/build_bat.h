/*
step-1
set args
step-2
form command:
compiler
transform to .? file //Deprecated
transform path (AT location, src location)
additional
step-3
filename
fin
*/
#ifndef _BUILD_BAT
#define _BUILD_BAT

#ifndef _MAIN
#include "main.h"
#endif
#ifndef _WINDOWS_
#include <windows.h>
#endif

#define MAX_BAT_FILE_SIZE		8192
#define MAX_BAT_COMMAND_SIZE	1024
#define STATEMENT_TYPE_LENGTH	6
#define STATEMENT_TYPE_COMPILER	1
#define STATEMENT_TYPE_PARTFILE	2
//#define STATEMENT_TYPE_ALTER	3 //Deprecated
#define STATEMENT_TYPE_DIST		4
#define STATEMENT_TYPE_SPACE	5
#define STATEMENT_TYPE_NEWLINE	6
#define N_ARG_FILE_TYPE_LENGTH 3
#define N_ARG_FILE_NAME 	1
#define N_ARG_FILE_PATH 	2
#define N_ARG_FILE_EXT  	4
#define SZ_ARG_FILE_NAME	"name"
#define SZ_ARG_FILE_PATH	"path"
#define SZ_ARG_FILE_EXT		"ext"
#define VAR_NAME_PWD	"pwd_"
#define VAR_NAME_ARGC	"argc_"
#define FOR_PARSE_FILE "\r\nFOR /F \"tokens=1 delims=?\" %%%%G IN (\"%%%i\" ) DO (\r\n  set %s=%%%%~nG\r\n  set %s=%%%%~dG%%%%~pG\r\n  set %s=%%%%~xG\r\n)"
#define FOR_PARSE_ARGS "\r\nSET /A argc_=0\r\nFOR %%%%A in (%%*) DO SET /A argc_+=1\r\n"
#define SET_PWD_VAR	"set pwd_=%%cd%%\r\n"
#define BEGIN_BAT_COMMAND "\r\n@echo off\r\nSETLOCAL\r\n"
#define END_BAT_COMMAND "\r\nENDLOCAL\r\n"

typedef struct _BatStatement{
	int type;		//Type of statement.
	char* compiler;	//
	int arg_th;		//n-th of arguments.
	int part_type;	//N_ARG_FILE_NAME, N_ARG_FILE_PATH, N_ARG_FILE_EXT
	//char** file_alter;	//file.cpp -> file.exe
	//int file_alter_len;
} BatStatement;
typedef struct _BatBuffer{
	char* buffer;
	int pointer;
	int flag;
} BatBuffer;
typedef struct _VarFileInfo{
	char* path;
	char* ext;
	char* name;
} VarFileInfo;
typedef struct _Step1_ArgInfo{
	char* argsName;
	char* argcName;
	char** argv;
	unsigned int argc;
} Step1_ArgInfo;
typedef struct _Step2_VarInfo{
	int* isSet;
	//char** elseVar;
	//int elseVarLen;
	int serialNum4Var;
	BatStatement* step2Statement;
	int step2StatementLen;
	BatBuffer batFileBuffer;
	BatBuffer* batCommandBuffer;
	int barCommandBufferLen;
} Step2_VarInfo;
typedef struct _Step3_FileInfo{
	char* dist_bat_name;
} Step3_FileInfo;

char* getBatFormVar(char* szVar);
char* getVarName(int nArg_th, int nType);
int getIntLen(int nDigit);
char* getSetFileVarCommand(int nArg_th);
BOOL writeBatFileBuffer(char* data);
BOOL writeBatCommandBuffer(char* data, int index);
BOOL writeBatCommandBuffer(char* data);
BOOL step2_partfile(BatStatement* userStatement);
BOOL step2_compiler(BatStatement* userStatement);
BOOL buildBatSaveBatFile();
BOOL buildBatStep3();
BOOL buildBatStep2(int statementLen, BatStatement* userStatement);
BOOL buildBatStep1(char** lpArgv, char** lpDefArg, int nArgvLen);
VOID buildBatClean();
VOID buildBatInitialize();

#endif //_BUILD_BAT

