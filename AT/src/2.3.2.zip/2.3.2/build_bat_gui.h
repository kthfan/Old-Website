
#ifndef _BUILD_BAT_GUI
#define _BUILD_BAT_GUI

#ifndef _MAIN
#include "main.h"
#endif
#ifndef _BUILD_BAT
#include "build_bat.h"
#endif //_BUILD_BAT
#ifndef _WINDOWS_
#include <windows.h>
#endif

#define STEP_NUMBER	3
#define STEP1_TAB	"Setting Arguments"
#define STEP2_TAB	"Setting Content"
#define STEP3_TAB	"Name .bat File"



HWND createTabControl(HWND hwndParent, char** szTabNames, int nTabNameLen);
VOID initializeBuildBatGUI(HWND hwndParent);
VOID initializeBuildBatIf(HWND hDlg, UINT uMessage, WPARAM wParam, LPARAM lParam );
VOID initializeBuildBatFor(HWND hDlg, UINT uMessage, WPARAM wParam, LPARAM lParam );
BOOL onTabNotify(HWND hwndTab, LPARAM lParam);
BOOL buildBatUserMenu( HWND hDlg, UINT uMessage, WPARAM wParam, LPARAM lParam );
VOID setBatIfCombo(HWND hList);
VOID setBatForCombo(HWND hList);
VOID showStepPage(int nIndex);
VOID onSwitchToStep1Page();
VOID onSwitchToStep2Page();
VOID onSwitchToStep3Page();
VOID onLeaveFromStep1Page();
VOID onLeaveFromStep2Page();
VOID onLeaveFromStep3Page();
VOID onSwitchStepPages(int nCurrentSel);
VOID onLeaveStepPages(int nCurrentSel);
BOOL CALLBACK BuildBatStep1PageProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK BuildBatStep2PageProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK BuildBatStep3PageProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK BuildBatStep2SectionProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK BuildBatStep2IfProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK BuildBatStep2ForProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);



// main.h
extern HINSTANCE g_hInst;
extern HWND hBuildBatTab, hBuildBatDlg;
extern HWND hBuildBatStepPages[STEP_NUMBER];
extern char* getEditText(HWND hEdit);
extern BOOL updateListBoxViewWidth(HWND hListBox);
extern void freeArray(void** ptr, int len);
extern char** getStrArrayFromListBox(HWND hListBox, int nListBoxLen);
extern VOID insertComboBoxText(HWND hComboBox, char* szText, int nIndex);
extern VOID insertListBoxText(HWND hListBox, char* szText, int nIndex);
extern VOID setListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
extern VOID appendListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
extern VOID insertListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen, int nIndex);
extern VOID insertComboBoxTexts(HWND hComboBox, char** lpTexts, int nTestsLen, int nIndex);
extern VOID setComboBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
extern VOID appendComboBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
extern int getDuplicateStr(char** lpArrayMain, char** lpArrayVice,int nArrayMainLen, int nArrayViceLen, int nStartIndex);
extern char** toNonEmptyStrArray(char** lpArray, int nArrayLen);
extern int getNonEmptyStrArrayCount(char** lpArray, int nArrayLen);
extern char** catStrArray(char** lpArray1, char** lpArray2,int nArray1Len, int nArray2Len);
extern int isStrArrayDuplicate(char** lpArray, int nArrayLen);
extern char** copyStrArray(char** lpArrayDist, char** lpArraySrc, int nArrayLen);

// build_bat.h
extern VOID buildBatInitialize();
extern BOOL buildBatStep1(char** lpArgv, char** lpDefArg, int nArgvLen);





#endif //_BUILD_BAT_GUI