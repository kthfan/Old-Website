
#ifndef _MAIN
#include "main.h"
#endif //_MAIN

//solve_config.h
extern CompilerInfo* findCompilerInfo(char* name);
extern BOOL add_compiler_list(CompilerInfo* info);
extern CompilerInfo* copy_complier_array();

//main.h
StringArray fileListArray;
CompilerInfo* ptrSelListBox = NULL;
unsigned int complier_len;
unsigned int tmp_complier_len;
CompilerInfo* complier_array;
CompilerInfo* tmp_complier_array;
HINSTANCE g_hInst;
HWND hQuery4FileDlg = NULL;
HWND hConfirmDlg = NULL;
WNDPROC lpCmdEditHwndProc;
char szAppName[14] = "Assembly Tool";
char szSelectOpt[MAX_COMPILER_STR_LENGTH];
HWND hCompilerComboBox, hMaCompilerList, hEditCodeBn
	,hOBn, hRBn, hQBn ,hREdit ,hOpenBn ,hCmdEdit
	, hManageCompilerDlg, hFileList, hCompileBn
	, hDelFileBn, hClearFileBn
	, hBuildBatTab, hBuildBatDlg;
HWND hBuildBatStepPages[STEP_NUMBER];
char file_name_buf[MAX_PATH];
char exe_name_buf[MAX_PATH];
char tmp_exe_buf[MAX_PATH];
char AT_PWD[MAX_PATH];
char loc_dir[MAX_PATH];
BOOL remove_old = FALSE;
HWND g_hwnd;

int WINAPI WinMain (HINSTANCE hThisInstance,
	HINSTANCE hPrevInstance,
	LPSTR lpszArgument,
	int nCmdShow)
{
	
	HWND hwnd;               /* This is the handle for our window */
	MSG messages;            /* Here messages to the application are saved */
	WNDCLASSEX wincl;        /* Data structure for the windowclass */

	/* The Window structure */
	wincl.hInstance = hThisInstance;
	wincl.lpszClassName = szAppName;
	wincl.lpfnWndProc = WindowProcedure;      /* This function is called by windows */
	wincl.style = CS_DBLCLKS;                 /* Catch double-clicks */
	wincl.cbSize = sizeof (WNDCLASSEX);

	/* Use default icon and mouse-pointer */
	wincl.hIcon = LoadIcon (NULL, "AppIcon");
	wincl.hIconSm = LoadIcon (hThisInstance, "AppIcon");
	wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
	wincl.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);                 /*menu */
	wincl.cbClsExtra = 0;                      /* No extra bytes after the window class */
	wincl.cbWndExtra = 0;                      /* structure or the window instance */
	/* Use Windows's default colour as the background of the window */
	wincl.hbrBackground = (HBRUSH) COLOR_BACKGROUND;

	/* Register the window class, and if it fails quit the program */
	if (!RegisterClassEx (&wincl))
		return 0;

	g_hInst = hThisInstance;
	/* The class is registered, let's create the program*/
	hwnd = CreateWindowEx (
		0,                   /* Extended possibilites for variation */
		(LPCSTR) szAppName,         /* Classname */
		(LPCSTR) szAppName,       /* Title Text */
		WS_OVERLAPPEDWINDOW|WS_EX_ACCEPTFILES, /* default window */
		500,       /* Windows decides the position */
		200,       /* where the window ends up on the screen */
		APP_WIDTH,                 /* The programs width */
		APP_HEIGHT,                 /* and height in pixels */
		HWND_DESKTOP,        /* The window is a child-window to desktop */
		NULL,                /*use class menu */
		hThisInstance,       /* Program Instance handler */
		NULL                 /* No Window Creation data */
		);

	/* Make the window visible on the screen */
	ShowWindow (hwnd, nCmdShow);

	/* Run the message loop. It will run until GetMessage() returns 0 */
	while (GetMessage (&messages, NULL, 0, 0))
	{
		/* Translate virtual-key messages into character messages */
		TranslateMessage(&messages);
		/* Send message to WindowProcedure */
		DispatchMessage(&messages);
	}

	/* The program return-value is 0 - The value that PostQuitMessage() gave */
	return messages.wParam;
}

char* getEditText(HWND hEdit){
	char* buf;
	int len,size;
	len = GetWindowTextLength(hEdit)+1;
	size = len*sizeof(char);
	buf = (char*) malloc(size);
	ZeroMemory(buf, size);
	GetWindowText(hEdit, &buf[0], len);
	return buf;
}
void update_opts(void){
	ZeroMemory(szSelectOpt,sizeof(char)*MAX_COMPILER_STR_LENGTH);
	int ItemIndex = SendMessage(hCompilerComboBox, (UINT) CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0);
    SendMessage(hCompilerComboBox, (UINT) CB_GETLBTEXT, (WPARAM) ItemIndex, (LPARAM) szSelectOpt);
    
}
int file_exists(char* filename){
	FILE *file;
    if ((file = fopen(filename, "r")))
    {
    	
        fclose(file);
        return 1;
    }
    return 0;
}
/*
void asm_file(char* filename,char* dist_file,HWND hwnd){
	char* cmd;
	char* szFo;
	char* var_dist;
	int cmd_len, src_len, dist_len, cm_path_len, fo_len, addal_len;
	CompilerInfo opt;
	chdir(PWD);
	opt = findCompilerInfo(szSelectOpt)[0];
	cm_path_len = strlen(opt.path);
	fo_len = strlen(opt.fileout);
	addal_len = strlen(opt.additional);
	src_len = strlen(filename);
	dist_len = strlen(dist_file)+2; //"dist_file"
	szFo = opt.fileout;
	var_dist = (char*) malloc((dist_len+1)*sizeof(char));
	ZeroMemory(var_dist,(dist_len+1)*sizeof(char));
	sprintf(var_dist,"\"%s\"",dist_file);
	if(opt.fileout[0] == FILE_OUT_NO_OPT){
		fo_len = 0;
		szFo = "";
	}else if(opt.fileout[0] == FILE_OUT_NO_ARG){
		dist_len = 0;
		ZeroMemory(var_dist,sizeof(char));
		fo_len = 0;
		szFo = "";
	}
	cmd_len = sizeof(char)*(cm_path_len+addal_len+fo_len+dist_len+src_len+strlen(LOG_FILE_NAME)+9);
	cmd = (char*) malloc (cmd_len);
	
	ZeroMemory(cmd,cmd_len);
	// mknasm.bat in out 32
	sprintf(cmd,"%s \"%s\" %s%s %s > %s",opt.path, filename, szFo, var_dist, opt.additional, LOG_FILE_NAME);
	//MessageBox(g_hwnd,cmd,"command",MB_OK);
	system(cmd);
	free(var_dist);
	free(cmd);
}
void check_dist_asm(char* filename,HWND hwnd){
	chdir(PWD);
	solve_fo_ext(file_name_buf,exe_name_buf);
	int len = (strlen(exe_name_buf)+4)* sizeof(char);
	char* buf = (char*) malloc(len);
	ZeroMemory(buf,len);
	sprintf(buf,"%s.exe",exe_name_buf);
	if(file_exists(exe_name_buf) || file_exists(buf)){
		DialogBox(g_hInst, "FileExists", hwnd, (DLGPROC)Query4FileDlgProc );
	}
	update_opts();
	if(exe_name_buf[0]==0) return;
	DialogBox(g_hInst, "ConfirmBox", hwnd, (DLGPROC)ConfirmDlgProc );
	if(exe_name_buf[0]==0) return;
	asm_file(file_name_buf,exe_name_buf,hwnd);
	check_asm_success(hwnd);
	if(remove_old) remove_old=FALSE;
	free(buf);
}
*/
int getEditText4Path(HWND hEdit,int maxLen,char* dist){
	int len = GetWindowTextLength(hEdit) + 1;
	if(len>maxLen) return 1;
	ZeroMemory(dist,sizeof(char)*MAX_PATH);
	GetWindowText(hEdit, &dist[0], len);
	if (dist[0]==0) return 1;
	if (dist[len-1]=='\\' || dist[len-1]=='/') return 1;
	bool is_abs = (len>=3 && ('a'<=dist[0] && dist[0]<='z') || ('A'<=dist[0] && dist[0]<='Z'));
	is_abs = is_abs && (dist[1]==':' && (dist[2]=='\\' || dist[2]=='/'));
	
	if(!is_abs){
		char* buf_1 = (char*)malloc(sizeof(char)*len);
		strcpy(buf_1,dist);
		int i,j,file_len=strlen(file_name_buf);
		for(i=file_len-1;i>=0;i-=1){
			if(file_name_buf[i]=='\\' || file_name_buf[i]=='/') break;
		}
		i+=1;
		ZeroMemory(dist,sizeof(char)*len);
		for(j=0;j<i;j+=1){
			dist[j] = file_name_buf[j];
		}
		strcat(dist,buf_1);	
		free(buf_1);
	}
	return 0;
}

void solve_fo_ext(char* filename,char* dist){
	int i,len=strlen(filename),ext_idx;
	for(i=len;i>=0;i-=1){
		if(filename[i]=='.'){
			ext_idx=i;
			break;
		}
	}
	len = sizeof(char)*(ext_idx+5);
	memset(dist,0,len);
	for(i=0;i<ext_idx;i+=1) dist[i]=filename[i];
	strcat(dist,".exe");
}

void check_asm_success(HWND hwnd){
	int len = (strlen(exe_name_buf)+5)*sizeof(char);
	char* buf = (char*) malloc(len);
	ZeroMemory(buf,len);
	sprintf(buf,"%s.exe",exe_name_buf);
	if(!(file_exists(exe_name_buf) || file_exists(buf))){
		if(remove_old && rename(tmp_exe_buf, exe_name_buf) != 0){
			MessageBox(hwnd, "Unable to restore the file.", "Error", MB_OK);
		}
		MessageBox(hwnd, "Assemble fail.", "Error", MB_OK);
		HANDLE hThread ;
		DWORD threadID ;
		int len2 = (strlen(LOG_FILE_NAME)+strlen(AT_PWD)+17)*sizeof(char);
		char* buf2 = (char*) malloc(len2);
		ZeroMemory(buf2,len2);
		sprintf(buf2,"type \"%s\\%s\" & pause",AT_PWD,LOG_FILE_NAME);
		hThread = CreateThread( 0, 0, (LPTHREAD_START_ROUTINE)cmdThread,(VOID* ) buf2, 0, &threadID ) ;
	}else{
		if(remove_old && remove(tmp_exe_buf) != 0){
			int len2 = (strlen(tmp_exe_buf)+29)*sizeof(char);
			char* buf2 = (char*) malloc(len2);
			ZeroMemory(buf2,len2);
			sprintf(buf2,"Unable to remove tmp file \"%s\"",tmp_exe_buf);
			MessageBox(hwnd, buf2, "Error", MB_OK);
			free(buf2);
		}
	}
	free(buf);
}
void create_tmp_exe(HWND hwnd){
	do{
		ZeroMemory(tmp_exe_buf,MAX_PATH*sizeof(char));
		sprintf(tmp_exe_buf,"%s.%i",exe_name_buf,rand());
	}while(file_exists(tmp_exe_buf));
	
	if(rename(exe_name_buf, tmp_exe_buf) != 0){
		MessageBox(hwnd, "Unable to overwrite the file.", "Error", MB_OK);
		ZeroMemory(exe_name_buf,1);
	}	
	
}
char* fileList2Str(char** lpFileList, int nFileListLen){
	char* szRes;
	int nResLen, i;
	nResLen = 0;
	for(i=0;i<nFileListLen;i++){
		nResLen += strlen(lpFileList[i]) + 1;
	}
	szRes = (char*) malloc(sizeof(char)*nResLen);
	ZeroMemory(szRes,sizeof(char)*nResLen);
	nFileListLen--;
	for(i=0;i<nFileListLen;i++){
		strcat(szRes,lpFileList[i]);
		strcat(szRes," ");
	}
	strcat(szRes,lpFileList[nFileListLen]);
	nFileListLen++;
	return szRes;
}
VOID asm_multiple_files(char** lpFileList, int nFileListLen){
	char* cmd;
	char* cprName;
	char* szFo;
	char* var_dist;
	char* filename;
	char* dist_file;
	int cmd_len, cprName_len, src_len, dist_len, fo_len, addal_len;
	CompilerInfo opt;
	filename = getSurroundQuotesFileList(lpFileList, nFileListLen);
	dist_file = exe_name_buf;
	opt = findCompilerInfo(szSelectOpt)[0];
	//cm_path_len = strlen(opt.path);
	cprName = getExceptDirName(opt.path);
	cprName_len = strlen(cprName);
	fo_len = strlen(opt.fileout);
	addal_len = strlen(opt.additional);
	src_len = strlen(filename);
	dist_len = strlen(dist_file)+2; //"dist_file"
	szFo = opt.fileout;
	var_dist = (char*) malloc((dist_len+1)*sizeof(char));
	ZeroMemory(var_dist,(dist_len+1)*sizeof(char));
	sprintf(var_dist,"\"%s\"",dist_file);
	if(opt.fileout[0] == FILE_OUT_NO_OPT){
		fo_len = 0;
		szFo = "";
	}else if(opt.fileout[0] == FILE_OUT_NO_ARG){
		dist_len = 0;
		ZeroMemory(var_dist,sizeof(char));
		fo_len = 0;
		szFo = "";
	}

	cmd_len = sizeof(char)*(cprName_len+addal_len+fo_len+dist_len+src_len+strlen(AT_PWD)+strlen(LOG_FILE_NAME)+22);
	cmd = (char*) malloc (cmd_len);
	
	ZeroMemory(cmd,cmd_len);
	char* szCompilerDir = getDirName(opt.path);
	chdir(szCompilerDir);

	// mknasm.bat in out 32
	sprintf(cmd,"call \"%s\" %s %s%s %s > \"%s\\%s\" 2>&1",cprName, filename, szFo, var_dist, opt.additional, AT_PWD, LOG_FILE_NAME);
	//MessageBox(g_hwnd,cmd,"command",MB_OK);
	system(cmd);

	free(cprName);
	chdir(AT_PWD);
	free(szCompilerDir);
	free(filename);
	free(var_dist);
	free(cmd);
}
int check_multiple_files_exists(char** lpFileList, int nFileListLen){
	int i;
	for(i=0;i<nFileListLen;i++){
		if(!file_exists(lpFileList[i]))
			return i;
	}
	return -1;
}
char* getDirName(char* filename){
	char* szRes;
	int nFileNameLen, nResLen, i;
	nFileNameLen = strlen(filename);
	for(i=nFileNameLen-1;i>=0;i--){
		if(filename[i] == '\\') break;
	}
	if(i==-1) nResLen = nFileNameLen;
	else nResLen = i + 1;
	szRes = (char*) malloc(sizeof(char)*(nResLen + 1));
	ZeroMemory(szRes , sizeof(char)*(nResLen + 1));
	strncpy(szRes, filename, nResLen);
	return szRes;
}
char* getExceptDirName(char* filename){
	char* szRes;
	int nFileNameLen, nResLen, i;
	nFileNameLen = strlen(filename);
	for(i=nFileNameLen-1;i>=0;i--){
		if(filename[i] == '\\') break;
	}
	if(i==-1) nResLen = nFileNameLen;
	else nResLen = nFileNameLen - i - 1;
	szRes = (char*) malloc(sizeof(char)*(nResLen + 1));
	ZeroMemory(szRes , sizeof(char)*(nResLen + 1));
	strncpy(szRes, filename+i+1, nResLen);
	return szRes;
}
char* getStrFromListBox(HWND hListBox, int nIndex){
	int strlen;
	char* szRes;
	strlen = SendMessage(hFileList, LB_GETTEXTLEN, nIndex, 0) + 1;
	szRes = (char*) malloc(sizeof(char)*strlen);
	ZeroMemory(szRes,sizeof(char)*strlen);
	SendMessage(hListBox, LB_GETTEXT , nIndex, (LPARAM) szRes);
	return szRes;
}
char** getStrArrayFromListBox(HWND hListBox, int nListBoxLen){
	char** szList;
	int i;
	szList = (char**) malloc(sizeof(char*)*nListBoxLen);
	ZeroMemory(szList,sizeof(char*)*nListBoxLen);
	for(i=0;i<nListBoxLen;i++){
		szList[i] = getStrFromListBox(hListBox, i);
	}
	return szList;	
}
char** get_multiple_files_from_list(int nFileListLen){
	return getStrArrayFromListBox(hFileList, nFileListLen);	
}
VOID compile_multiple_files(){
	char** lpFileList;
	char* szTemp;
	int nFileListLen, i, nTemp;
	nFileListLen = SendMessage(hFileList, LB_GETCOUNT, 0, 0);
	if(nFileListLen == LB_ERR ) {
		MessageBox(g_hwnd, "Unable to get input files.", "Error", MB_OK);
		return;
	}
	//chdir(PWD);
	lpFileList = get_multiple_files_from_list(nFileListLen);
	fileListArray.array = lpFileList;
	fileListArray.length = nFileListLen;
	if((i = check_multiple_files_exists(lpFileList,nFileListLen)) != -1){
		nTemp = sizeof(char)*(strlen(lpFileList[i]) + 23);
		szTemp = (char*) malloc(nTemp);
		ZeroMemory(szTemp, nTemp);
		sprintf(szTemp,"File does not exists: %s", lpFileList[i]);
		MessageBox(g_hwnd, szTemp, "Error", MB_OK);
		free(szTemp);
		goto label_compile_multiple_files_end;
	}
	ZeroMemory(file_name_buf,MAX_PATH);
	ZeroMemory(exe_name_buf,MAX_PATH);
	if(nFileListLen>0){
		int nExtNameSize;
		char* szExtName;
		strcpy(file_name_buf, lpFileList[0]);
		solve_fo_ext(file_name_buf,exe_name_buf);
		nExtNameSize = (strlen(exe_name_buf)+5)* sizeof(char);
		szExtName = (char*) malloc(nExtNameSize);
		
		ZeroMemory(szExtName, nExtNameSize);
		sprintf(szExtName,"%s.exe",exe_name_buf);
		if(file_exists(exe_name_buf) || file_exists(szExtName))
			DialogBox(g_hInst, "FileExists", g_hwnd, (DLGPROC)Query4FileDlgProc );
		free(szExtName);
		if(exe_name_buf[0]==0) return;
	}
	update_opts();
	DialogBox(g_hInst, "ConfirmBox", g_hwnd, (DLGPROC)ConfirmDlgProc );
	if(exe_name_buf[0]==0) {
		if(remove_old) remove_old=FALSE;
		return;
	}
	asm_multiple_files(lpFileList, nFileListLen);
	check_asm_success(g_hwnd);
	if(remove_old) remove_old=FALSE;
	
	label_compile_multiple_files_end:
	for(i=0;i<nFileListLen;i++){
		free(lpFileList[i]);
	}
	free(lpFileList);
}
char* toATPathFileName(char* filename){
	char* szRes;
	int nResSize = (strlen(AT_PWD) + strlen(filename) + 2) * sizeof(char);
	szRes = (char*) malloc(nResSize);
	ZeroMemory(szRes, nResSize);
	sprintf(szRes , "%s\\%s", AT_PWD, filename);
	return szRes;
}
char* getSurroundQuotes(char* szFile){
	char* szRes;
	int nResSize = sizeof(char)*(strlen(szFile) + 3);
	szRes = (char*) malloc(nResSize);
	ZeroMemory(szRes,nResSize);
	sprintf(szRes,"\"%s\"",szFile);
	return szRes;
}
char* getSurroundQuotesFileList(char** lpFileList, int nFileListLen){
	char* szRes;
	char* szTemp;
	int nResLen = nFileListLen*3;
	int i;
	for(i=0;i<nFileListLen;i++){
		nResLen += strlen(lpFileList[i]);
	}
	szRes = (char*) malloc(sizeof(char)*nResLen);
	ZeroMemory(szRes,sizeof(char)*nResLen); 
	nFileListLen--;
	for(i=0;i<nFileListLen;i++){
		szTemp = getSurroundQuotes(lpFileList[i]);
		strcat(szRes,szTemp);
		strcat(szRes," ");
		free(szTemp);
	}
	szTemp = getSurroundQuotes(lpFileList[nFileListLen]);
	strcat(szRes,szTemp);
	nFileListLen++;
	return szRes;
}
VOID insertListBoxText(HWND hListBox, char* szText, int nIndex){
	if(nIndex==-1) nIndex = SendMessage(hListBox, LB_GETCOUNT , 0, 0) - 1;
	SendMessage(hListBox,(UINT) LB_INSERTSTRING, (WPARAM) nIndex, (LPARAM) szText);
	updateListBoxViewWidth(hListBox);
	SendMessage(hListBox, LB_SETCURSEL, nIndex, 0);
}
VOID insertComboBoxText(HWND hComboBox, char* szText, int nIndex){
	if(nIndex==-1) nIndex = SendMessage(hComboBox, CB_GETCOUNT , 0, 0) - 1;
	SendMessage(hComboBox,(UINT) CB_INSERTSTRING, (WPARAM) nIndex, (LPARAM) szText);
	SendMessage(hComboBox, CB_SETCURSEL, nIndex, 0);
}
VOID setListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen){
	SendMessage(hListBox, LB_RESETCONTENT, 0, 0);
	insertListBoxTexts(hListBox, lpTexts, nTestsLen, -1);
}
VOID insertListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen, int nIndex){
	int i;
	if(nIndex==-1) nIndex = SendMessage(hListBox, LB_GETCOUNT , 0, 0) - 1;
	for(i=0;i<nTestsLen;i++){
		SendMessage(hListBox, (UINT) LB_INSERTSTRING,(WPARAM) nIndex++,(LPARAM) lpTexts[i]); 
	}
	updateListBoxViewWidth(hListBox);
	SendMessage(hListBox, LB_SETCURSEL, nIndex-1, 0);
}
VOID appendListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen){
	insertListBoxTexts(hListBox, lpTexts, nTestsLen, -1);
}
VOID setComboBoxTexts(HWND hComboBox, char** lpTexts, int nTestsLen){
	SendMessage(hComboBox, CB_RESETCONTENT, 0, 0);
	insertComboBoxTexts(hComboBox, lpTexts, nTestsLen, -1);
}
VOID insertComboBoxTexts(HWND hComboBox, char** lpTexts, int nTestsLen, int nIndex){
	int i;
	if(nIndex==-1) nIndex = SendMessage(hComboBox, CB_GETCOUNT , 0, 0) - 1;
	for(i=0;i<nTestsLen;i++){
		SendMessage(hComboBox, (UINT) CB_INSERTSTRING,(WPARAM) nIndex++,(LPARAM) lpTexts[i]); 
	}
	SendMessage(hComboBox, CB_SETCURSEL, nIndex-1, 0);
}
VOID appendComboBoxTexts(HWND hComboBox, char** lpTexts, int nTestsLen){
	insertComboBoxTexts(hComboBox, lpTexts, nTestsLen, -1);
}
int calcLBItemWidth(HWND hLB, char* Text)
{
    RECT r;
    HDC hLBDC = GetDC(hLB);
    HDC hDC = CreateCompatibleDC(hLBDC);
    HFONT hFont = (HFONT) SendMessage(hLB, WM_GETFONT, 0, 0);
    HGDIOBJ hOrgFont = SelectObject(hDC, hFont);
    ZeroMemory(&r, sizeof(r));
    DrawText(hDC, Text, -1, &r, DT_CALCRECT|DT_SINGLELINE|DT_NOCLIP);
    SelectObject(hDC, hOrgFont);
    DeleteDC(hDC);
    ReleaseDC(hLB, hLBDC);
    return (r.right - r.left) + (2 * GetSystemMetrics(SM_CXEDGE));
}
BOOL updateListBoxViewWidth(HWND hListBox){
	char** lpFileList;
	int nFileListLen, i, nWidth, nLargestWidth;
	nLargestWidth = 0;
	nFileListLen = SendMessage(hFileList, LB_GETCOUNT, 0, 0);
	if(nFileListLen == LB_ERR ) return FALSE;
	lpFileList = get_multiple_files_from_list(nFileListLen);
	for (i = 0; i < nFileListLen; i++){
        nWidth = calcLBItemWidth(hListBox, lpFileList[i]);
        if (nWidth > nLargestWidth) nLargestWidth = nWidth;
    }
    SendMessage(hListBox, LB_SETHORIZONTALEXTENT, nLargestWidth, 0);
	return TRUE;
}
void freeArray(void** ptr, int len){
	int i;
	for(i=0;i<len;i++){
		free(ptr[i]);
	}
	free(ptr);
}
/** Search from nStartIndex(lpArrayMain), if duplicate, returns the index in lpArrayMain, else returns -1.*/
int getDuplicateStr(char** lpArrayMain, char** lpArrayVice,int nArrayMainLen, int nArrayViceLen, int nStartIndex){
	int i,j;
	for(i=nStartIndex;i<nArrayMainLen;i++){
		for(j=0;j<nArrayViceLen;j++){
			if(strcmp(lpArrayMain[i], lpArrayVice[j]) == 0) return i;
		}
	}
	return -1;
}
/** Get the array that is not empty (!= ""), and each element in the array is referring to lpArray[i](won't malloc).*/
char** toNonEmptyStrArray(char** lpArray, int nArrayLen){
	int i, nResLen;
	char** lpRes;
	nResLen = getNonEmptyStrArrayCount(lpArray, nArrayLen);
	lpRes = (char**) malloc(sizeof(char*)*nResLen);
	for(i=0;i<nArrayLen;i++){
		if(lpArray[i][0] != 0) lpRes[i] = lpArray[i]; 
	}
	return lpRes;
}
int getNonEmptyStrArrayCount(char** lpArray, int nArrayLen){
	int i, nResLen;
	nResLen = 0;
	for(i=0;i<nArrayLen;i++){
		if(lpArray[i][0] != 0) nResLen++; 
	}
	return nResLen;
}
char** catStrArray(char** lpArray1, char** lpArray2,int nArray1Len, int nArray2Len){
	char** lpRes;
	int nResLen,i,j;
	nResLen = nArray1Len + nArray2Len;
	lpRes = (char**) malloc(sizeof(char*)*(nResLen));
	for(i=0;i<nArray1Len;i++){
		int nSize;
		char* szTmp;
		nSize = (strlen(lpArray1[i])+1) * sizeof(char);
		szTmp = (char*) malloc(nSize);
		ZeroMemory(szTmp, nSize);
		strcpy(szTmp, lpArray1[i]);
		lpRes[i] = szTmp;
	}
	for(i=0,j=nArray1Len;i<nArray2Len;i++,j++){
		int nSize;
		char* szTmp;
		nSize = (strlen(lpArray2[i])+1) * sizeof(char);
		szTmp = (char*) malloc(nSize);
		ZeroMemory(szTmp, nSize);
		strcpy(szTmp, lpArray2[i]);
		lpRes[j] = szTmp;
	}
	return lpRes;
}
int isStrArrayDuplicate(char** lpArray, int nArrayLen){
	int i,j;
	for(i=0;i<nArrayLen;i++){
		for(j=i+1;j<nArrayLen;j++){
			if(strcmp(lpArray[i], lpArray[j]) == 0) return j;
		}
	}
	return -1;
}
char** copyStrArray(char** lpArrayDist, char** lpArraySrc, int nArrayLen){
	int i;
	for(i=0;i<nArrayLen;i++){
		strcpy(lpArrayDist[i], lpArraySrc[i]);
	}
	return lpArrayDist;
}

