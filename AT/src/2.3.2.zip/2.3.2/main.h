
#ifndef _MAIN
#define _MAIN

#ifndef _SOLVE_CONFIG
#include "solve_config.h"
#endif //_SOLVE_CONFIG
#ifndef _WIN_PROCEDURE
#include "win_procedure.h"
#endif //_WIN_PROCEDURE

#include <windows.h>
//#include <wingdi.h>
#include <ShellAPI.h>
#include <string.h>
#include <stdio.h>
#include "Resource.h"
#include <direct.h>
#include <time.h>
#include <commctrl.h>

#define MAX_COMPILER_STR_LENGTH 256
#define ITEM_ALIGN_TOP 10
#define ITEM_ALIGN_LEFT 10
#define ITEM_SEP_HOR 20
#define ITEM_SEP_VER 30
#define TEXT_HEIGHT 20
#define ITEM_CMD_WIDTH 60
#define CMD_ALIGN_TOP (ITEM_ALIGN_TOP+70)
#define DROP_ALIGN_TOP (CMD_ALIGN_TOP+100)
#define ITEM_COMR_WIDTH 180
#define ITEM_FILE_LIST_WIDTH 300
#define ITEM_FILE_LIST_HEIGHT 150
#define CONFIG_FILE_NAME "AT.conf"
#define COMRINFO_ATTR_NUM 4
#define LOG_FILE_NAME "AT.log"

#pragma comment (lib,"user32.lib")
#pragma comment (lib,"gdi32.lib")
#pragma comment (lib,"Shell32.lib")
#pragma comment (lib,"Comdlg32.lib")
#pragma comment(lib, "comctl32.lib")

typedef struct _StringArray{
	char** array;
	int length;
}StringArray;

//solve_config.h
extern VOID bulid_compiler_list();
extern VOID rebulid_compiler_list();
extern BOOL remove_compiler_list(char* item);
extern BOOL load_config();
extern BOOL save_config();
extern BOOL check_config();
extern VOID buildDlgCompilerList();
//win_procedure.h
extern LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);
extern BOOL CALLBACK Query4FileDlgProc(HWND, UINT, WPARAM, LPARAM);
extern BOOL CALLBACK ConfirmDlgProc(HWND, UINT, WPARAM, LPARAM);
extern BOOL CALLBACK SettingCompilerDlgProc(HWND, UINT, WPARAM, LPARAM);
extern BOOL CALLBACK ManageCompilerDlgProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK CmdLineProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
extern LRESULT userMenu( HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam );
extern void cmdThread(char* buf);

//main.h
void update_opts(void);
int file_exists(char* filename);
//void asm_file(char* filename,char* dist_file,HWND hwnd);
//void check_dist_asm(char* filename,HWND hwnd);
int getEditText4Path(HWND hEdit,int maxLen,char* dist);
void solve_fo_ext(char* filename,char* dist);
void check_asm_success(HWND hwnd);
void create_tmp_exe(HWND hwnd);
char* getEditText(HWND hEdit);
VOID insertComboBoxText(HWND hComboBox, char* szText, int nIndex);
VOID insertListBoxText(HWND hListBox, char* szText, int nIndex);
VOID setListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
VOID insertListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen, int nIndex);
VOID appendListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
VOID setComboBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
VOID insertComboBoxTexts(HWND hComboBox, char** lpTexts, int nTestsLen, int nIndex);
VOID appendComboBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
char* toATPathFileName(char* filename);
VOID compile_multiple_files();
char** get_multiple_files_from_list(int nFileListlen);
int check_multiple_files_exists(char** lpFileList, int nFileListLen);
char* getDirName(char* filename);
char* getExceptDirName(char* filename);
VOID asm_multiple_files(char** lpFileList, int nFileListLen);
char* fileList2Str(char** lpFileList, int nFileListLen);
char* getSurroundQuotesFileList(char** lpFileList, int nFileListLen);
char* getSurroundQuotes(char* szFile);
BOOL updateListBoxViewWidth(HWND hListBox);
int calcLBItemWidth(HWND hLB, char* Text);
void freeArray(void** ptr, int len);
char* getStrFromListBox(HWND hListBox, int nIndex);
char** getStrArrayFromListBox(HWND hListBox, int nListBoxLen);
int getDuplicateStr(char** lpArrayMain, char** lpArrayVice,int nArrayMainLen, int nArrayViceLen, int nStartIndex);
char** toNonEmptyStrArray(char** lpArray, int nArrayLen);
int getNonEmptyStrArrayCount(char** lpArray, int nArrayLen);
char** catStrArray(char** lpArray1, char** lpArray2,int nArray1Len, int nArray2Len);
int isStrArrayDuplicate(char** lpArray, int nArrayLen);
char** copyStrArray(char** lpArrayDist, char** lpArraySrc, int nArrayLen);
#endif //_MAIN



