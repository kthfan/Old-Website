//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//

#define APP_WIDTH	450
#define APP_HEIGHT	450

#define IDC_TXT1 1
#define IDC_TXT2 2
#define IDC_BIT 3
#define IDC_ASM 4
#define IDC_OBN 5
#define IDC_RBN 6
#define IDC_QBN 7
#define IDC_REdit 8
#define IDC_DropHint 9
#define IDC_OpenFileBn 10
#define IDC_TXT3 11
#define IDC_TXT4 12
#define IDC_TXT5 13
#define IDC_TXT6 14
#define IDC_TXT7 15
#define IDC_TXT8 16
#define IDC_TXT9 17
#define IDC_CmdEdit 18
#define IDC_TXT10 19 
#define IDR_MENU1 20
#define IDM_Compiler 21
#define IDC_CN_Edit 22
#define IDC_CP_Edit 23
#define IDC_CF_Edit 24
#define IDC_CA_Edit 25
#define IDC_TXT11 26
#define IDC_TXT12 27
#define IDC_TXT13 28
#define IDC_TXT14 29
#define IDC_TXT15 30
#define IDC_CP_BN 31
#define IDC_MC_List 32
#define IDC_MCA_BN 33
#define IDC_MCD_BN 34
#define IDC_MCS_BN 35
#define IDC_CF_CB 36
#define IDM_BuildBat 37
#define IDC_FileList 38
#define IDC_CompileBn 39
#define IDC_DelFileBn 40
#define IDC_ClearFileBn 41
#define IDC_ConfirmFilesList 42
#define IDC_BuildBatTab 43
#define IDC_BBN_BN 44
#define IDC_BBL_BN 45
#define IDC_BB1_A_BN 46
#define IDC_BB1_D_BN 47
#define IDC_BB1_List 48
#define IDC_BB1_Edit 49
#define IDC_BB2_List 50
#define IDC_BB3_Edit 51
#define IDC_BB3_S_Edit 52
#define IDD_Step1Page 53
#define IDD_Step2Page 54
#define IDD_Step3Page 55
#define IDC_BB2_Arg_List 56
#define IDC_BB2_AA_BN 57
#define IDC_BB2_D_BN 58
#define IDC_BB2_AFE_BN 59
#define IDC_BB2_S_BN 60
#define IDC_BB2_AT_BN 61
#define IDC_BB2_AT_Edit 62
#define IDC_BB2_If_BN 63
#define IDC_BB2_If_L_Edit 64
#define IDC_BB2_If_R_Edit 65
#define IDC_BB2_If_E_Edit 66
#define IDC_BB2_If_C_List 67
#define IDC_BB2_If_L_List 68
#define IDC_BB2_If_R_List 69
#define IDC_BB2_If_E_List 70
#define IDC_BB2_If_N_CB 71
#define IDC_BB2_If_1_RB 72
#define IDC_BB2_If_2_RB 73
#define IDC_BB2_SA_BN 74
#define IDC_BB2_For_1_RB 75
#define IDC_BB2_For_2_RB 76
#define IDC_BB2_For_E_Edit 77
#define IDC_BB2_For_E_List 78
#define IDC_BB2_For_R1_Edit 79
#define IDC_BB2_For_R2_Edit 80
#define IDC_BB2_For_R3_Edit 81
#define IDC_BB2_For_R1_List 82
#define IDC_BB2_For_R2_List 83
#define IDC_BB2_For_R3_List 84
#define IDC_BB1_Args_Edit 85
#define IDC_BB1_Argc_Edit 86
#define IDC_EditCodeBn 87


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
