
#ifndef _SOLVE_CONFIG
#include "solve_config.h"
#endif //_SOLVE_CONFIG

HANDLE check_config(char* szConfig){
	static HANDLE fileHandle ;
    WIN32_FIND_DATA findData ;

    fileHandle = FindFirstFile( "*.*", &findData );
    if( fileHandle != INVALID_HANDLE_VALUE ) {
        do {
            if( !(findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) &&
				strcmp(findData.cFileName,szConfig) == 0 ){
					fileHandle =  CreateFile( szConfig, GENERIC_READ ,
						FILE_SHARE_READ, 0, OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL, 0 );
					if(fileHandle == INVALID_HANDLE_VALUE ) return NULL; 
					return fileHandle;
			}
        } while( FindNextFile( fileHandle, &findData ) ) ;
    }
    
    return NULL;
}
BOOL load_config(){
	HANDLE fileHandle;
	char szBuffer[MAX_CONFIG_FILE_SIZE] = {0};
	DWORD len;
	int  i;
	CompilerInfo* tmp_info;
	char ch;
	int rol = 0;
	DWORD ln = 0;
	DWORD nMark = 0;
	DWORD nTmp;
	_getcwd( loc_dir, MAX_PATH );
	chdir(AT_PWD);

	//check if exist
	if( (fileHandle = check_config(CONFIG_FILE_NAME)) == NULL )
		return FALSE;
	//read file
	if(!ReadFile(fileHandle,szBuffer,MAX_CONFIG_FILE_SIZE,&len,NULL)){
		CloseHandle( fileHandle );
		return FALSE;
	}
	CloseHandle( fileHandle );
	//find length of complier_array
	for(i=0;i<len;i++){
		if(szBuffer[i] == '\r' && i+1<len && szBuffer[i+1] == '\n' )
			ln++;
	}
	complier_len = ln;
	complier_array = (CompilerInfo*) malloc(sizeof(CompilerInfo)*complier_len);
	ln = 0;
	tmp_info = complier_array;
	//load into complier_array
	for(i=0;i<len;i++){
		ch = szBuffer[i];
		switch(ch){
			case '\t':
				nTmp = i-nMark+1;
				switch(rol){
					case 0:
						tmp_info->name = (char*) malloc(sizeof(char)*nTmp);
						ZeroMemory(tmp_info->name,sizeof(char)*nTmp);
						strncpy(tmp_info->name,szBuffer+nMark,nTmp-1);
						break;
					case 1:
						tmp_info->path = (char*) malloc(sizeof(char)*nTmp);
						ZeroMemory(tmp_info->path,sizeof(char)*nTmp);
						strncpy(tmp_info->path,szBuffer+nMark,nTmp-1);
						break;
					case 2:
						tmp_info->fileout = (char*) malloc(sizeof(char)*nTmp);
						ZeroMemory(tmp_info->fileout,sizeof(char)*nTmp);
						strncpy(tmp_info->fileout,szBuffer+nMark,nTmp-1);
						break;
					case 3:
						tmp_info->additional = (char*) malloc(sizeof(char)*nTmp);
						ZeroMemory(tmp_info->additional,sizeof(char)*nTmp);
						strncpy(tmp_info->additional,szBuffer+nMark,nTmp-1);
						break;
				}
				rol = (rol+1) % COMRINFO_ATTR_NUM;
				nMark = i+1;
				break;
			case '\n':
				nTmp = i-nMark+1;
				if(i-1 >= 0 && szBuffer[i-1] == '\r')
					nTmp--;
				tmp_info->additional = (char*) malloc(sizeof(char)*nTmp);
				ZeroMemory(tmp_info->additional,sizeof(char)*nTmp);
				strncpy(tmp_info->additional,szBuffer+nMark,nTmp-1);
				//complier_array[ln] = tmp_info;
				rol = 0;
				nMark = i+1;
				ln++;
				tmp_info++;
				break;
			default:
				break;
		}
		
	}
	chdir(loc_dir);
	return TRUE;
}
BOOL save_config(){
	_getcwd( loc_dir, MAX_PATH );
	chdir(AT_PWD);
	char szBuffer[MAX_CONFIG_FILE_SIZE] = {0};
	DWORD len;
	int i;
	HANDLE fileHandle = CreateFile( CONFIG_FILE_NAME, GENERIC_READ | GENERIC_WRITE,
		0, 0, CREATE_ALWAYS, 0, 0 ) ;
	if(fileHandle == NULL || fileHandle == INVALID_HANDLE_VALUE )
		return FALSE;
		
	for(i=0;i<complier_len;i++){
		strcat(szBuffer,complier_array[i].name);
		strcat(szBuffer,"\t");
		strcat(szBuffer,complier_array[i].path);
		strcat(szBuffer,"\t");
		strcat(szBuffer,complier_array[i].fileout);
		strcat(szBuffer,"\t");
		strcat(szBuffer,complier_array[i].additional);
		strcat(szBuffer,"\r\n");
	}
	if(!WriteFile( fileHandle, szBuffer,(DWORD)strlen( szBuffer ) + 1, &len, NULL )){
		CloseHandle( fileHandle );
		return FALSE;
	}
	CloseHandle( fileHandle );
	chdir(loc_dir);
	return TRUE;
}
VOID rebulid_compiler_list(){
	int  k; 
	SendMessage(hCompilerComboBox, CB_RESETCONTENT, 0, 0);
	for (k = 0; k < complier_len; k += 1)
	{
    	SendMessage(hCompilerComboBox,(UINT) CB_ADDSTRING,(WPARAM) 0,(LPARAM) complier_array[k].name); 
	}
	SendMessage(hCompilerComboBox, CB_SETCURSEL, 0, 0);
	
}
VOID bulid_compiler_list(){
	
	if( !load_config() ){
		complier_len = 6;
		complier_array = (CompilerInfo*) malloc(sizeof(CompilerInfo)*complier_len);
		complier_array[0].name = "nasm(x86)";
		complier_array[0].path = "Assembly\\mknasm.bat";
		complier_array[0].fileout = "";
		complier_array[0].additional = "32";
		complier_array[1].name = "nasm(x64)";
		complier_array[1].path = "Assembly\\mknasm.bat";
		complier_array[1].fileout = "";
		complier_array[1].additional = "64";
		complier_array[2].name = "masm(x86)";
		complier_array[2].path = "Assembly\\mkmasm.bat";
		complier_array[2].fileout = "";
		complier_array[2].additional = "32";
		complier_array[3].name = "masm(x64)";
		complier_array[3].path = "Assembly\\mkmasm.bat";
		complier_array[3].fileout = "";
		complier_array[3].additional = "64";
		complier_array[4].name = "VC(x86)";
		complier_array[4].path = "VC\\compile_x86.bat";
		complier_array[4].fileout = "\x01";
		complier_array[4].additional = "";
		complier_array[5].name = "VC(x64)";
		complier_array[5].path = "VC\\compile_x64.bat";
		complier_array[5].fileout = "\x01";
		complier_array[5].additional = "";
	}
	
	rebulid_compiler_list();
	
	if(!save_config()){
		MessageBox(g_hwnd,"Unable save config.","Error",MB_OK);
	}
}
BOOL change_compiler_list(CompilerInfo* info){
	int index;
	CompilerInfo* dist_info;
	if((index = SendMessage(hCompilerComboBox, (UINT) CB_FINDSTRINGEXACT, (WPARAM) 0, (LPARAM) info->name)) != CB_ERR){
		dist_info = findCompilerInfo(info->name);
		dist_info[0] = info[0];
		return TRUE;
	}
	SendMessage(hCompilerComboBox, CB_SETCURSEL, index, 0);
	//For DlgCompilerList
	if(hManageCompilerDlg != NULL){
		index = SendMessage(hMaCompilerList, (UINT) LB_FINDSTRINGEXACT, (WPARAM) 0, (LPARAM) info->name);
		SendMessage(hMaCompilerList, LB_SETCURSEL, index, 0);
	}//For DlgCompilerList
	return FALSE;
}
BOOL add_compiler_list(CompilerInfo* info){
	int index;
	if(SendMessage(hCompilerComboBox, (UINT) CB_FINDSTRINGEXACT, (WPARAM) 0, (LPARAM) info->name) == CB_ERR){
		CompilerInfo* tmp_array;
		int i;
		int nSelectedIndex;
		tmp_array = (CompilerInfo*) malloc(sizeof(CompilerInfo)*(complier_len+1));
		for(i=0;i<complier_len;i++){
			tmp_array[i] = complier_array[i];
		}
		tmp_array[complier_len] = info[0];
		free(complier_array);
		complier_array = tmp_array;
		nSelectedIndex = SendMessage(hMaCompilerList, LB_GETCURSEL, 0, 0);
		SendMessage(hCompilerComboBox,(UINT) CB_INSERTSTRING,(WPARAM) nSelectedIndex,(LPARAM) info->name);
		//For DlgCompilerList
		if(hManageCompilerDlg != NULL){
			SendMessage(hMaCompilerList,(UINT) LB_INSERTSTRING, (WPARAM) nSelectedIndex, (LPARAM) info->name);
			SendMessage(hMaCompilerList, LB_SETCURSEL, nSelectedIndex+1, 0);
		}//For DlgCompilerList

		complier_len++;
		return TRUE;
	}
	change_compiler_list(info);
	return FALSE;
}
BOOL remove_compiler_list(char* item){
	int index;
	if((index = SendMessage(hCompilerComboBox, (UINT) CB_FINDSTRINGEXACT, (WPARAM) 0, (LPARAM) item)) != CB_ERR){
		CompilerInfo* tmp_array;
		int i;//complier_array
		int j;//tmp_array
		tmp_array = (CompilerInfo*) malloc(sizeof(CompilerInfo)*(complier_len-1));
		for(i=0,j=0;i<complier_len;i++){
			if(strcmp(complier_array[i].name,item)!=0){
				tmp_array[j] = complier_array[i];
				j++;
			}
		}
		free(complier_array);
		complier_array = tmp_array;
		SendMessage(hCompilerComboBox,(UINT) CB_DELETESTRING ,(WPARAM) index,(LPARAM) 0);
		SendMessage(hCompilerComboBox, CB_SETCURSEL, 0, 0);
		//For DlgCompilerList
		if(hManageCompilerDlg != NULL){
			index = SendMessage(hMaCompilerList, (UINT) LB_FINDSTRINGEXACT, (WPARAM) 0, (LPARAM) item);
			SendMessage(hMaCompilerList,(UINT) LB_DELETESTRING,(WPARAM) index,(LPARAM) 0);
			SendMessage(hMaCompilerList, LB_SETCURSEL, index-1<0?0:index-1, 0);
		}//For DlgCompilerList
		complier_len--;
		return TRUE;
	}
	return FALSE;
}

CompilerInfo* findCompilerInfo(char* name){
	int k;
	for (k = 0; k < complier_len; k += 1)
	{
    	if(strcmp(name,complier_array[k].name)==0)
    		return &complier_array[k];
	}
	return NULL;
}
VOID buildDlgCompilerList(){
	if(hManageCompilerDlg == NULL) return;
	int  k; 
	for (k = 0; k < complier_len; k += 1)
	{
    	SendMessage(hMaCompilerList,(UINT) LB_ADDSTRING, (WPARAM) 0, (LPARAM) complier_array[k].name);
	}
	SendMessage(hMaCompilerList, LB_SETCURSEL, 0, 0);
}
CompilerInfo* copy_complier_array(){
	int i;
	CompilerInfo* ptr_info = (CompilerInfo*) malloc(sizeof(CompilerInfo)*complier_len);
	for(i=0;i<complier_len;i++){
		ptr_info[i] = complier_array[i];
	}
	return ptr_info;
}

