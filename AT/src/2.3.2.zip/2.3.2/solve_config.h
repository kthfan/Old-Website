


#ifndef _SOLVE_CONFIG
#define _SOLVE_CONFIG

#ifndef _MAIN
#include "main.h"
#endif
#ifndef _WINDOWS_
#include <windows.h>
#endif


#define MAX_COMPILER_STR_LENGTH 256
#define MAX_CONFIG_FILE_SIZE 4096
#define FILE_OUT_NO_OPT 0
#define FILE_OUT_NO_ARG 1

struct _CompilerInfo{
	char* name;
	char* path;
	char* fileout;
	char* additional;
	//unsigned int;
};
typedef struct _CompilerInfo CompilerInfo;




VOID bulid_compiler_list();
VOID rebulid_compiler_list();
BOOL add_compiler_list(CompilerInfo* info);
BOOL remove_compiler_list(char* item);
BOOL change_compiler_list(CompilerInfo* info);
BOOL load_config();
BOOL save_config();
BOOL check_config();
CompilerInfo* findCompilerInfo(char* name);
VOID buildDlgCompilerList();
CompilerInfo* copy_complier_array();

//main.h
extern char* toATPathFileName(char* filename);
extern unsigned int complier_len;
extern CompilerInfo* complier_array;
extern CompilerInfo* tmp_complier_array;
extern HWND hCompilerComboBox, hMaCompilerList, hManageCompilerDlg;
extern HWND g_hwnd;
extern char AT_PWD[MAX_PATH];
extern char loc_dir[MAX_PATH];

#endif //_SOLVE_CONFIG

