


#ifndef _AT_LIB
#include "AT_lib.h"
#endif //_AT_LIB

/* Start LinkedList*/
LinkedList* createLinkedList(){
	LinkedList* pList = (LinkedList*) malloc(sizeof(LinkedList));
	pList->head = (LinkedList::Node*) malloc(sizeof(LinkedList::Node));
	pList->head->next = pList->head;
	pList->head->rear = pList->head;
	pList->head->pointer = 0;
	pList->length = 0;
}

void* getLinkedList(LinkedList* pList, unsigned int nIndex){
	LinkedList::Node* tmpNode = pList->head->next;
	nIndex = nIndex%pList->length;
	for(int i=0; i<nIndex; i++){
		tmpNode = tmpNode->next;
	}
	return tmpNode->pointer;
}
unsigned int insertLinkedList(LinkedList* pList, void* ptr, unsigned int nIndex){
	LinkedList::Node* newNode = (LinkedList::Node*) malloc(sizeof(LinkedList::Node));
	LinkedList::Node* tmpNode = pList->head->next;
	nIndex = nIndex%pList->length;
	for(int i=0; i<nIndex; i++){
		tmpNode = tmpNode->next;
	}
	newNode->pointer = ptr;
	newNode->next = tmpNode;
	newNode->rear = tmpNode->rear;
	tmpNode->rear = newNode;
	pList->length++;
	return pList->length;
}
unsigned int removeLinkedList(LinkedList* pList, unsigned int nIndex){
	LinkedList::Node* tmpNode = pList->head->next;
	nIndex = nIndex%pList->length;
	for(int i=0; i<nIndex; i++){
		tmpNode = tmpNode->next;
	}
	tmpNode->next->rear = tmpNode->rear;
	tmpNode->rear->next = tmpNode->next;
	free(tmpNode);
	pList->length--;
	return pList->length;
}
void clearLinkedList(LinkedList* pList){
	LinkedList::Node* tmpNode = pList->head->next;
	LinkedList::Node* nextNode;
	for(int i=0; i<pList->length; i++){
		nextNode = tmpNode->next;
		free(tmpNode);
		tmpNode = nextNode;
	}
	pList->head->next = pList->head;
	pList->head->rear = pList->head;
	pList->length = 0;
}
void** linkedList2Array(LinkedList* pList){
	LinkedList::Node* tmpNode = pList->head->next;
	void** lpRes = (void**) malloc(sizeof(void*)*pList->length);
	for(int i=0; i<pList->length; i++){
		lpRes[i] = tmpNode->pointer;
		tmpNode = tmpNode->next;
	}
	return lpRes;
}
/* End LinkedList*/

/* Start File Operation*/
int file_exists(char* filename){
	FILE *file;
    if ((file = fopen(filename, "r")))
    {
    	
        fclose(file);
        return 1;
    }
    return 0;
}
int check_multiple_files_exists(char** lpFileList, int nFileListLen){
	int i;
	for(i=0;i<nFileListLen;i++){
		if(!file_exists(lpFileList[i]))
			return i;
	}
	return -1;
}
/* End File Operation*/

/* Start String And Array */
char* getDirName(char* filename){
	char* szRes;
	int nFileNameLen, nResLen, i;
	nFileNameLen = strlen(filename);
	for(i=nFileNameLen-1;i>=0;i--){
		if(filename[i] == '\\') break;
	}
	if(i==-1) nResLen = nFileNameLen;
	else nResLen = i + 1;
	szRes = (char*) malloc(sizeof(char)*(nResLen + 1));
	ZeroMemory(szRes , sizeof(char)*(nResLen + 1));
	strncpy(szRes, filename, nResLen);
	return szRes;
}
char* getExceptDirName(char* filename){
	char* szRes;
	int nFileNameLen, nResLen, i;
	nFileNameLen = strlen(filename);
	for(i=nFileNameLen-1;i>=0;i--){
		if(filename[i] == '\\') break;
	}
	if(i==-1) nResLen = nFileNameLen;
	else nResLen = nFileNameLen - i - 1;
	szRes = (char*) malloc(sizeof(char)*(nResLen + 1));
	ZeroMemory(szRes , sizeof(char)*(nResLen + 1));
	strncpy(szRes, filename+i+1, nResLen);
	return szRes;
}

char* fileList2Str(char** lpFileList, int nFileListLen){
	char* szRes;
	int nResLen, i;
	nResLen = 0;
	for(i=0;i<nFileListLen;i++){
		nResLen += strlen(lpFileList[i]) + 1;
	}
	szRes = (char*) malloc(sizeof(char)*nResLen);
	ZeroMemory(szRes,sizeof(char)*nResLen);
	nFileListLen--;
	for(i=0;i<nFileListLen;i++){
		strcat(szRes,lpFileList[i]);
		strcat(szRes," ");
	}
	strcat(szRes,lpFileList[nFileListLen]);
	nFileListLen++;
	return szRes;
}

char* getSurroundQuotes(char* szFile){
	char* szRes;
	int nResSize = sizeof(char)*(strlen(szFile) + 3);
	szRes = (char*) malloc(nResSize);
	ZeroMemory(szRes,nResSize);
	sprintf(szRes,"\"%s\"",szFile);
	return szRes;
}
char* getSurroundQuotesFileList(char** lpFileList, int nFileListLen){
	char* szRes;
	char* szTemp;
	int nResLen = nFileListLen*3;
	int i;
	for(i=0;i<nFileListLen;i++){
		nResLen += strlen(lpFileList[i]);
	}
	szRes = (char*) malloc(sizeof(char)*nResLen);
	ZeroMemory(szRes,sizeof(char)*nResLen); 
	nFileListLen--;
	for(i=0;i<nFileListLen;i++){
		szTemp = getSurroundQuotes(lpFileList[i]);
		strcat(szRes,szTemp);
		strcat(szRes," ");
		free(szTemp);
	}
	szTemp = getSurroundQuotes(lpFileList[nFileListLen]);
	strcat(szRes,szTemp);
	nFileListLen++;
	return szRes;
}

void freeArray(void** ptr, int len){
	int i;
	for(i=0;i<len;i++){
		free(ptr[i]);
	}
	free(ptr);
}
char** copyStrArray(char** lpArrayDist, char** lpArraySrc, int nArrayLen){
	int i;
	for(i=0;i<nArrayLen;i++){
		strcpy(lpArrayDist[i], lpArraySrc[i]);
	}
	return lpArrayDist;
}
char** catStrArray(char** lpArray1, char** lpArray2,int nArray1Len, int nArray2Len){
	char** lpRes;
	int nResLen,i,j;
	nResLen = nArray1Len + nArray2Len;
	lpRes = (char**) malloc(sizeof(char*)*(nResLen));
	for(i=0;i<nArray1Len;i++){
		int nSize;
		char* szTmp;
		nSize = (strlen(lpArray1[i])+1) * sizeof(char);
		szTmp = (char*) malloc(nSize);
		ZeroMemory(szTmp, nSize);
		strcpy(szTmp, lpArray1[i]);
		lpRes[i] = szTmp;
	}
	for(i=0,j=nArray1Len;i<nArray2Len;i++,j++){
		int nSize;
		char* szTmp;
		nSize = (strlen(lpArray2[i])+1) * sizeof(char);
		szTmp = (char*) malloc(nSize);
		ZeroMemory(szTmp, nSize);
		strcpy(szTmp, lpArray2[i]);
		lpRes[j] = szTmp;
	}
	return lpRes;
}
/** Get the array that is not empty (!= ""), and each element in the array is referring to lpArray[i](won't malloc).*/
char** toNonEmptyStrArray(char** lpArray, int nArrayLen){
	int i, nResLen;
	char** lpRes;
	nResLen = getNonEmptyStrArrayCount(lpArray, nArrayLen);
	lpRes = (char**) malloc(sizeof(char*)*nResLen);
	for(i=0;i<nArrayLen;i++){
		if(lpArray[i][0] != 0) lpRes[i] = lpArray[i]; 
	}
	return lpRes;
}
int getNonEmptyStrArrayCount(char** lpArray, int nArrayLen){
	int i, nResLen;
	nResLen = 0;
	for(i=0;i<nArrayLen;i++){
		if(lpArray[i][0] != 0) nResLen++; 
	}
	return nResLen;
}
/** Search from nStartIndex(lpArrayMain), if duplicate, returns the index in lpArrayMain, else returns -1.*/
int getDuplicateStr(char** lpArrayMain, char** lpArrayVice,int nArrayMainLen, int nArrayViceLen, int nStartIndex){
	int i,j;
	for(i=nStartIndex;i<nArrayMainLen;i++){
		for(j=0;j<nArrayViceLen;j++){
			if(strcmp(lpArrayMain[i], lpArrayVice[j]) == 0) return i;
		}
	}
	return -1;
}
int isStrArrayDuplicate(char** lpArray, int nArrayLen){
	int i,j;
	for(i=0;i<nArrayLen;i++){
		for(j=i+1;j<nArrayLen;j++){
			if(strcmp(lpArray[i], lpArray[j]) == 0) return j;
		}
	}
	return -1;
}
/* End String  And Array */


/* Start Win Control*/
int calcLBItemWidth(HWND hLB, char* Text)
{
    RECT r;
    HDC hLBDC = GetDC(hLB);
    HDC hDC = CreateCompatibleDC(hLBDC);
    HFONT hFont = (HFONT) SendMessage(hLB, WM_GETFONT, 0, 0);
    HGDIOBJ hOrgFont = SelectObject(hDC, hFont);
    ZeroMemory(&r, sizeof(r));
    DrawText(hDC, Text, -1, &r, DT_CALCRECT|DT_SINGLELINE|DT_NOCLIP);
    SelectObject(hDC, hOrgFont);
    DeleteDC(hDC);
    ReleaseDC(hLB, hLBDC);
    return (r.right - r.left) + (2 * GetSystemMetrics(SM_CXEDGE));
}
BOOL updateListBoxViewWidth(HWND hListBox){
	char** lpFileList;
	int nFileListLen, i, nWidth, nLargestWidth;
	nLargestWidth = 0;
	nFileListLen = SendMessage(hListBox, LB_GETCOUNT, 0, 0);
	if(nFileListLen == LB_ERR ) return FALSE;
	lpFileList = getStrArrayFromListBox(hListBox, nFileListLen);
	for (i = 0; i < nFileListLen; i++){
        nWidth = calcLBItemWidth(hListBox, lpFileList[i]);
        if (nWidth > nLargestWidth) nLargestWidth = nWidth;
    }
    SendMessage(hListBox, LB_SETHORIZONTALEXTENT, nLargestWidth, 0);
	return TRUE;
}

char* getEditText(HWND hEdit){
	char* buf;
	int len,size;
	len = GetWindowTextLength(hEdit)+1;
	size = len*sizeof(char);
	buf = (char*) malloc(size);
	ZeroMemory(buf, size);
	GetWindowText(hEdit, &buf[0], len);
	return buf;
}
char* getStrFromListBox(HWND hListBox, int nIndex){
	int strlen;
	char* szRes;
	strlen = SendMessage(hListBox, LB_GETTEXTLEN, nIndex, 0) + 1;
	szRes = (char*) malloc(sizeof(char)*strlen);
	ZeroMemory(szRes,sizeof(char)*strlen);
	SendMessage(hListBox, LB_GETTEXT , nIndex, (LPARAM) szRes);
	return szRes;
}
char** getStrArrayFromListBox(HWND hListBox, int nListBoxLen){
	char** szList;
	int i;
	szList = (char**) malloc(sizeof(char*)*nListBoxLen);
	ZeroMemory(szList,sizeof(char*)*nListBoxLen);
	for(i=0;i<nListBoxLen;i++){
		szList[i] = getStrFromListBox(hListBox, i);
	}
	return szList;	
}

VOID insertListBoxText(HWND hListBox, char* szText, int nIndex){
	if(nIndex==-1) nIndex = SendMessage(hListBox, LB_GETCOUNT , 0, 0) - 1;
	SendMessage(hListBox,(UINT) LB_INSERTSTRING, (WPARAM) nIndex, (LPARAM) szText);
	updateListBoxViewWidth(hListBox);
	SendMessage(hListBox, LB_SETCURSEL, nIndex, 0);
}
VOID insertComboBoxText(HWND hComboBox, char* szText, int nIndex){
	if(nIndex==-1) nIndex = SendMessage(hComboBox, CB_GETCOUNT , 0, 0) - 1;
	SendMessage(hComboBox,(UINT) CB_INSERTSTRING, (WPARAM) nIndex, (LPARAM) szText);
	SendMessage(hComboBox, CB_SETCURSEL, nIndex, 0);
}
VOID setListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen){
	SendMessage(hListBox, LB_RESETCONTENT, 0, 0);
	insertListBoxTexts(hListBox, lpTexts, nTestsLen, -1);
}
VOID insertListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen, int nIndex){
	int i;
	if(nIndex==-1) nIndex = SendMessage(hListBox, LB_GETCOUNT , 0, 0) - 1;
	for(i=0;i<nTestsLen;i++){
		SendMessage(hListBox, (UINT) LB_INSERTSTRING,(WPARAM) nIndex++,(LPARAM) lpTexts[i]); 
	}
	updateListBoxViewWidth(hListBox);
	SendMessage(hListBox, LB_SETCURSEL, nIndex-1, 0);
}
VOID appendListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen){
	insertListBoxTexts(hListBox, lpTexts, nTestsLen, -1);
}
VOID setComboBoxTexts(HWND hComboBox, char** lpTexts, int nTestsLen){
	SendMessage(hComboBox, CB_RESETCONTENT, 0, 0);
	insertComboBoxTexts(hComboBox, lpTexts, nTestsLen, -1);
}
VOID insertComboBoxTexts(HWND hComboBox, char** lpTexts, int nTestsLen, int nIndex){
	int i;
	if(nIndex==-1) nIndex = SendMessage(hComboBox, CB_GETCOUNT , 0, 0) - 1;
	for(i=0;i<nTestsLen;i++){
		SendMessage(hComboBox, (UINT) CB_INSERTSTRING,(WPARAM) nIndex++,(LPARAM) lpTexts[i]); 
	}
	SendMessage(hComboBox, CB_SETCURSEL, nIndex-1, 0);
}
VOID appendComboBoxTexts(HWND hComboBox, char** lpTexts, int nTestsLen){
	insertComboBoxTexts(hComboBox, lpTexts, nTestsLen, -1);
}
/* End Win Control*/