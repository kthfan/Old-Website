
#ifndef _AT_LIB
#define _AT_LIB

#ifndef _WINDOWS_
#include <windows.h>
#endif
//#include <wingdi.h>
#include <ShellAPI.h>
#include <string.h>
#include <stdio.h>
#include "Resource.h"
#include <direct.h>
#include <time.h>
#include <commctrl.h>



/* Start LinkedList*/
struct _LinkedList {
		typedef struct _Node{
			struct _Node* next;
			struct _Node* rear;
			void* pointer;
		} Node;	
		Node* head;
		unsigned int length;
};
typedef struct _LinkedList LinkedList;

LinkedList* createLinkedList();
void* getLinkedList(LinkedList* pList, unsigned int nIndex);
unsigned int insertLinkedList(LinkedList* pList, void* ptr, unsigned int nIndex);
unsigned int removeLinkedList(LinkedList* pList, unsigned int nIndex);
void clearLinkedList(LinkedList* pList);
void** linkedList2Array(LinkedList* pList);
/* End LinkedList*/


/* Start File Operation*/
int file_exists(char* filename);
int check_multiple_files_exists(char** lpFileList, int nFileListLen);
/* End File Operation*/



/* Start String And Array */
char* getDirName(char* filename);
char* getExceptDirName(char* filename);

char* fileList2Str(char** lpFileList, int nFileListLen);

char* getSurroundQuotes(char* szFile);
char* getSurroundQuotesFileList(char** lpFileList, int nFileListLen);

void freeArray(void** ptr, int len);
char** copyStrArray(char** lpArrayDist, char** lpArraySrc, int nArrayLen);
char** catStrArray(char** lpArray1, char** lpArray2,int nArray1Len, int nArray2Len);
char** toNonEmptyStrArray(char** lpArray, int nArrayLen);
int getNonEmptyStrArrayCount(char** lpArray, int nArrayLen);
int getDuplicateStr(char** lpArrayMain, char** lpArrayVice,int nArrayMainLen, int nArrayViceLen, int nStartIndex);
int isStrArrayDuplicate(char** lpArray, int nArrayLen);
/* End String  And Array */


/* Start Win Control*/
BOOL updateListBoxViewWidth(HWND hListBox);
int calcLBItemWidth(HWND hLB, char* Text);

char* getEditText(HWND hEdit);
char* getStrFromListBox(HWND hListBox, int nIndex);
char** getStrArrayFromListBox(HWND hListBox, int nListBoxLen);

VOID insertComboBoxText(HWND hComboBox, char* szText, int nIndex);
VOID insertListBoxText(HWND hListBox, char* szText, int nIndex);
VOID setListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
VOID insertListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen, int nIndex);
VOID appendListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
VOID setComboBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
VOID insertComboBoxTexts(HWND hComboBox, char** lpTexts, int nTestsLen, int nIndex);
VOID appendComboBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
/* End Win Control*/

#endif //_AT_LIB
