

#ifndef _BUILD_BAT_GUI
#include "build_bat_gui.h"
#endif //_BUILD_BAT_GUI

// build_bat.h
extern Step1_ArgInfo step1_ArgInfo;

//build_bat_gui.h
HWND  hBatNextBn, hBatLastBn, hBatStep1AddBn, hBatStep1DelBn
	, hBatStep1List, hBatStep1Edit,hBatStep1ArgsEdit
	, hBatStep1ArgcEdit, hBatStep2List, hBatStep2ArgList
	, hBatStep2AddArgBn, hBatStep2DelBn, hBatStep2AddForEachBn
	, hBatStep2SettingBn, hBatStep2AddTextBn, hBatStep2AddTextEdit
	,hBatStep3Edit;
BOOL isStep1Duplicate = FALSE;

HWND createTabControl(HWND hwndParent, char** szTabNames, int nTabNameLen) 
{ 
    RECT rcClient; 
    INITCOMMONCONTROLSEX icex;
    HWND hwndTab; 
    TCITEM tie; 
    int i; 
    TCHAR achTemp[256];  // Temporary buffer for strings.
    
 
    // Initialize common controls.
    icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
    icex.dwICC = ICC_TAB_CLASSES;
    InitCommonControlsEx(&icex);
    
    // Get the dimensions of the parent window's client area, and 
    // create a tab control child window of that size. Note that g_hInst
    // is the global instance handle.
    GetClientRect(hwndParent, &rcClient); 
	
    hwndTab = CreateWindow(WC_TABCONTROL, "", 
        WS_CHILD | WS_CLIPSIBLINGS | WS_VISIBLE, 
        0, 0, rcClient.right, rcClient.bottom, 
        hwndParent, NULL, g_hInst, NULL);
	
    if (hwndTab == NULL)
    { 
        return NULL; 
    }
 
    // Add tabs for each day of the week. 
    tie.mask = TCIF_TEXT | TCIF_IMAGE; 
    tie.iImage = -1; 
    tie.pszText = achTemp; 
    for (i = 0; i < nTabNameLen; i++) 
    { 
        ZeroMemory(achTemp,256);
        strcpy(achTemp, szTabNames[i]);
        if (TabCtrl_InsertItem(hwndTab, i, &tie) == -1) 
        { 
            DestroyWindow(hwndTab); 
            return NULL; 
        } 
    } 
    return hwndTab; 
}
VOID initializeBuildBatGUI(HWND hwndParent){
	char* szTabNames[STEP_NUMBER] = {STEP1_TAB, STEP2_TAB, STEP3_TAB};
	hBuildBatTab = createTabControl(hwndParent, szTabNames, STEP_NUMBER);
	hBuildBatStepPages[0] = CreateDialogParam(g_hInst, MAKEINTRESOURCEA(IDD_Step1Page), hBuildBatTab, (DLGPROC) BuildBatStep1PageProc, 0L);
	hBuildBatStepPages[1] = CreateDialogParam(g_hInst, MAKEINTRESOURCEA(IDD_Step2Page), hBuildBatTab, (DLGPROC) BuildBatStep2PageProc, 0L);
	hBuildBatStepPages[2] = CreateDialogParam(g_hInst, MAKEINTRESOURCEA(IDD_Step3Page), hBuildBatTab, (DLGPROC) BuildBatStep3PageProc, 0L);
	hBatNextBn = GetDlgItem(hBuildBatDlg,IDC_BBN_BN);
	hBatLastBn = GetDlgItem(hBuildBatDlg,IDC_BBL_BN);
	hBatStep1AddBn = GetDlgItem(hBuildBatStepPages[0],IDC_BB1_A_BN);
	hBatStep1DelBn = GetDlgItem(hBuildBatStepPages[0],IDC_BB1_D_BN);
	hBatStep1List = GetDlgItem(hBuildBatStepPages[0],IDC_BB1_List);
	hBatStep1Edit = GetDlgItem(hBuildBatStepPages[0],IDC_BB1_Edit);
	hBatStep1ArgsEdit = GetDlgItem(hBuildBatStepPages[0],IDC_BB1_Args_Edit);
	hBatStep1ArgcEdit = GetDlgItem(hBuildBatStepPages[0],IDC_BB1_Argc_Edit);
	hBatStep2List = GetDlgItem(hBuildBatStepPages[1],IDC_BB2_List);
	hBatStep2ArgList = GetDlgItem(hBuildBatStepPages[1],IDC_BB2_Arg_List);
	hBatStep2AddArgBn = GetDlgItem(hBuildBatStepPages[1],IDC_BB2_AA_BN);
	hBatStep2DelBn = GetDlgItem(hBuildBatStepPages[1],IDC_BB2_D_BN);
	hBatStep2AddForEachBn = GetDlgItem(hBuildBatStepPages[1],IDC_BB2_AFE_BN);
	hBatStep2SettingBn = GetDlgItem(hBuildBatStepPages[1],IDC_BB2_S_BN);
	hBatStep2AddTextBn = GetDlgItem(hBuildBatStepPages[1],IDC_BB2_AT_BN);
	hBatStep2AddTextEdit = GetDlgItem(hBuildBatStepPages[1],IDC_BB2_AT_Edit);
	hBatStep3Edit = GetDlgItem(hBuildBatStepPages[2],IDC_BB3_Edit);
	ShowWindow (hBuildBatStepPages[0], SW_SHOW);
	EnableWindow(hBatLastBn,FALSE);
	buildBatInitialize();
	onSwitchToStep1Page();
}
VOID initializeBuildBatIf(HWND hDlg, UINT uMessage, WPARAM wParam, LPARAM lParam ){
	char* szCnds[6] = {"==", "!=", ">", "<", ">=", "<="};
	HWND hCndList, hRList, hLList, hEList;
	hCndList = GetDlgItem(hDlg, IDC_BB2_If_C_List);
	hRList = GetDlgItem(hDlg, IDC_BB2_If_R_List);
	hLList = GetDlgItem(hDlg, IDC_BB2_If_L_List);
	hEList = GetDlgItem(hDlg, IDC_BB2_If_E_List);
	setComboBoxTexts(hCndList, szCnds, 6);
	setBatIfCombo(hRList);
	setBatIfCombo(hLList);
	setBatIfCombo(hEList);
	SendMessage(GetDlgItem(hDlg, IDC_BB2_If_1_RB), BM_SETCHECK, BST_CHECKED, 0);
}
VOID initializeBuildBatFor(HWND hDlg, UINT uMessage, WPARAM wParam, LPARAM lParam ){
	SetWindowText(GetDlgItem(hDlg, IDC_BB2_For_R1_Edit),"0");
	SetWindowText(GetDlgItem(hDlg, IDC_BB2_For_R2_Edit),"0");
	SetWindowText(GetDlgItem(hDlg, IDC_BB2_For_R3_Edit),"1");
	setBatForCombo(GetDlgItem(hDlg, IDC_BB2_For_E_List));
	setBatForCombo(GetDlgItem(hDlg, IDC_BB2_For_R1_List));
	setBatForCombo(GetDlgItem(hDlg, IDC_BB2_For_R2_List));
	setBatForCombo(GetDlgItem(hDlg, IDC_BB2_For_R3_List));
	SendMessage(GetDlgItem(hDlg, IDC_BB2_For_1_RB), BM_SETCHECK, BST_CHECKED, 0);
}
BOOL buildBatUserMenu( HWND hDlg, UINT uMessage, WPARAM wParam, LPARAM lParam ){
	int currentSel;
	switch( LOWORD( wParam )){
	case IDC_BBN_BN:
		currentSel = TabCtrl_GetCurSel(hBuildBatTab);
		if(currentSel < STEP_NUMBER - 1){
			showStepPage(currentSel+1);
		}
		break;
	case IDC_BBL_BN:
		currentSel = TabCtrl_GetCurSel(hBuildBatTab);
		if(currentSel > 0 ){
			showStepPage(currentSel-1);
		}
		break;
	case IDCANCEL:
    	EndDialog(hDlg, TRUE);
    	return (TRUE);
	default:
		return FALSE;
	
	}
	return TRUE;
}
BOOL onTabNotify(HWND hwndTab, LPARAM lParam)
{
    switch (((LPNMHDR)lParam)->code)
        {
            case TCN_SELCHANGING:
                {
                    int currentSel;
					currentSel = TabCtrl_GetCurSel(hwndTab);
					ShowWindow (hBuildBatStepPages[currentSel], SW_HIDE);
					onLeaveStepPages(currentSel);
					return FALSE;
                }
            case TCN_SELCHANGE:
                { 
					int currentSel;
					currentSel = TabCtrl_GetCurSel(hwndTab);
					ShowWindow (hBuildBatStepPages[currentSel], SW_SHOW);
					if(currentSel == STEP_NUMBER - 1){
						SetDlgItemText(hBuildBatDlg,IDC_BBN_BN,"Finish");
					}else{
						SetDlgItemText(hBuildBatDlg,IDC_BBN_BN,"Next");
					}
					if(currentSel == 0){
						EnableWindow(hBatLastBn,FALSE);
					}else if(!IsWindowEnabled(hBatLastBn)){
						EnableWindow(hBatLastBn,TRUE);
					}
					onSwitchStepPages(currentSel);
                    break;
                } 
        }
        return TRUE;
}
VOID showStepPage(int nIndex){
	HWND hParent = GetParent(hBuildBatTab);
	NMHDR nmhdr = {0};
	nmhdr.hwndFrom = hBuildBatTab;
	nmhdr.idFrom = GetDlgCtrlID(hBuildBatTab);
	nmhdr.code = TCN_SELCHANGING;
	if (SendMessage(hParent, WM_NOTIFY, (WPARAM)hBuildBatTab, (LPARAM)&nmhdr) == FALSE){
		TabCtrl_SetCurSel(hBuildBatTab, nIndex);
		nmhdr.code = TCN_SELCHANGE;
		SendMessage(hParent, WM_NOTIFY, (WPARAM)hBuildBatTab, (LPARAM)&nmhdr);
	}
}
VOID setBatIfCombo(HWND hList){
	int nStep1ListLen;
	char** szArgList;
	nStep1ListLen = SendMessage(hBatStep2ArgList, LB_GETCOUNT, 0, 0);
	if(nStep1ListLen != LB_ERR){
		szArgList = getStrArrayFromListBox(hBatStep2ArgList, nStep1ListLen);
		setComboBoxTexts(hList, szArgList, nStep1ListLen);
		freeArray((void**) szArgList, nStep1ListLen);
	}
}
VOID setBatForCombo(HWND hList){
	int nStep1ListLen;
	char** szArgList;
	nStep1ListLen = SendMessage(hBatStep2ArgList, LB_GETCOUNT, 0, 0);
	if(nStep1ListLen != LB_ERR){
		szArgList = getStrArrayFromListBox(hBatStep2ArgList, nStep1ListLen);
		setComboBoxTexts(hList, szArgList, nStep1ListLen);
		freeArray((void**) szArgList, nStep1ListLen);
	}
}

VOID onSwitchToStep1Page(){
	SetWindowText(hBatStep1ArgsEdit,step1_ArgInfo.argsName);
	SetWindowText(hBatStep1ArgcEdit,step1_ArgInfo.argcName);
}
VOID onSwitchToStep2Page(){
	if(isStep1Duplicate){
		MessageBox(hBuildBatDlg, "Duplicate parameter name.", "Note", MB_OK);
		showStepPage(0);
	}else {
		setListBoxTexts(hBatStep2ArgList, step1_ArgInfo.argv, step1_ArgInfo.argc);
		SendMessage(hBatStep2ArgList, (UINT) LB_ADDSTRING,(WPARAM) 0,(LPARAM) step1_ArgInfo.argsName);
		SendMessage(hBatStep2ArgList, (UINT) LB_ADDSTRING,(WPARAM) 0,(LPARAM) step1_ArgInfo.argcName); 
		SendMessage(hBatStep2ArgList, LB_SETCURSEL, 0, 0);
		updateListBoxViewWidth(hBatStep2ArgList);
	}
}
VOID onSwitchToStep3Page(){
	if(isStep1Duplicate){
		MessageBox(hBuildBatDlg, "Duplicate parameter name.", "Note", MB_OK);
		showStepPage(0);
	}
}
VOID onSwitchStepPages(int nCurrentSel){
	switch(nCurrentSel){
	case 0:
		onSwitchToStep1Page();
		break;
	case 1:
		onSwitchToStep2Page();
		break;
	case 2:
		onSwitchToStep3Page();
		break;
	}
}
VOID onLeaveFromStep1Page(){
	int nStep1ListLen;
	char** szArgList;
	char** szDefArg;
	nStep1ListLen = SendMessage(hBatStep1List, LB_GETCOUNT, 0, 0);
	if(nStep1ListLen != LB_ERR){
		char** catedArray;
		szDefArg = (char**) malloc(sizeof(char*)*2);
		szDefArg[0] = getEditText(hBatStep1ArgsEdit);
		szDefArg[1] = getEditText(hBatStep1ArgcEdit);
		szArgList = getStrArrayFromListBox(hBatStep1List, nStep1ListLen);
		catedArray = catStrArray(szArgList, szDefArg, nStep1ListLen, 2);
		if(isStrArrayDuplicate(catedArray , nStep1ListLen + 2) == -1){
			char** lpNonEmptyDA;
			lpNonEmptyDA = toNonEmptyStrArray( szDefArg, 2);
			buildBatStep1(szArgList, szDefArg , nStep1ListLen);
			free(lpNonEmptyDA);
			isStep1Duplicate = FALSE;
		}else {
			isStep1Duplicate = TRUE;
		}
		freeArray((void**) catedArray, nStep1ListLen + 2);
		free(szDefArg);
	}
}
VOID onLeaveFromStep2Page(){

}
VOID onLeaveFromStep3Page(){

}
VOID onLeaveStepPages(int nCurrentSel){
	switch(nCurrentSel){
	case 0:
		onLeaveFromStep1Page();
		break;
	case 1:
		onLeaveFromStep2Page();
		break;
	case 2:
		onLeaveFromStep3Page();
		break;
	}
}
/////////////////////////////////////////////////////////////////////////////
//
// StepPages Process Function
//
BOOL CALLBACK BuildBatStep1PageProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam){
    switch( uMsg )
 	{
 		case WM_INITDIALOG:
 			break;
		case WM_SHOWWINDOW:
			break;
 		case WM_COMMAND :
			switch( LOWORD( wParam )){
			case IDC_BB1_A_BN:
				char* szArgName;
				szArgName = getEditText(hBatStep1Edit);
				if(szArgName[0]==0) MessageBox(hDlg, "Please name the parameters.", "Note", MB_OK);
				else{
					insertListBoxText(hBatStep1List, szArgName, SendMessage(hBatStep1List, LB_GETCURSEL, 0, 0));
				}
				free(szArgName);
				SetWindowText(hBatStep1Edit,"");
				break;
			case IDC_BB1_D_BN:
				int nIndex;
				nIndex = SendMessage(hBatStep1List, (UINT) LB_GETCURSEL, (WPARAM) 0, (LPARAM) 0);
				SendMessage(hBatStep1List,(UINT) LB_DELETESTRING ,(WPARAM) nIndex,(LPARAM) 0);
				updateListBoxViewWidth(hBatStep1List);
				SendMessage(hBatStep1List, LB_SETCURSEL, nIndex-1<0?0:nIndex-1, 0);
				break;
			}
			break;
 		default :	
			return(FALSE);
	}
    return(TRUE);
}
BOOL CALLBACK BuildBatStep2PageProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam){
	int nIndex, nStrlen;
	char* szText;
    switch( uMsg )
 	{
 		case WM_INITDIALOG:
			
 			break;
		case WM_SHOWWINDOW:
			break;
 		case WM_COMMAND :
			switch( LOWORD( wParam )){
			case IDC_BB2_S_BN:
				DialogBox(g_hInst, "BuildBatStep2Section", hDlg, (DLGPROC) BuildBatStep2SectionProc);
				break;
			case IDC_BB2_D_BN:
				int nIndex;
				nIndex = SendMessage(hBatStep2List, (UINT) LB_GETCURSEL, (WPARAM) 0, (LPARAM) 0);
				SendMessage(hBatStep2List,(UINT) LB_DELETESTRING ,(WPARAM) nIndex,(LPARAM) 0);
				updateListBoxViewWidth(hBatStep2List);
				SendMessage(hBatStep2List, LB_SETCURSEL, nIndex-1<0?0:nIndex-1, 0);
				break;
			case IDC_BB2_AFE_BN:
				DialogBox(g_hInst, "BuildBatStep2For", hDlg, (DLGPROC) BuildBatStep2ForProc);
				break;
			case IDC_BB2_AA_BN:
				nIndex = SendMessage(hBatStep2ArgList, (UINT) LB_GETCURSEL, (WPARAM) 0, (LPARAM) 0);
				if(nIndex != LB_ERR ){
					nStrlen = SendMessage(hBatStep2ArgList, LB_GETTEXTLEN, nIndex, 0) + 1;
					szText = (char*) malloc(sizeof(char)*nStrlen);
					ZeroMemory(szText,sizeof(char)*nStrlen);
					SendMessage(hBatStep2ArgList, LB_GETTEXT , nIndex, (LPARAM) szText);
					insertListBoxText(hBatStep2List, szText, SendMessage(hBatStep2List, LB_GETCURSEL, 0, 0));
					free(szText);
				}
				break;
			case IDC_BB2_AT_BN:
				
				szText = getEditText(hBatStep2AddTextEdit);
				if(szText[0]==0) MessageBox(hDlg, "Please enter the text.", "Note", MB_OK);
				else{
					insertListBoxText(hBatStep2List, szText, SendMessage(hBatStep2List, LB_GETCURSEL, 0, 0));
				}
				free(szText);
				SetWindowText(hBatStep2AddTextEdit,"");
				break;
			case IDC_BB2_If_BN:
				DialogBox(g_hInst, "BuildBatStep2If", hDlg, (DLGPROC) BuildBatStep2IfProc);
				break;
			}
			break;
 		default :	
			return(FALSE);
	}
    return(TRUE);
}
BOOL CALLBACK BuildBatStep3PageProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam){
    switch( uMsg )
 	{
 		case WM_INITDIALOG:
 			break;
		case WM_SHOWWINDOW:
			break;
 		case WM_COMMAND :
			switch( LOWORD( wParam )){
			case IDC_BB1_A_BN:
				break;
			}
			break;
 		default :	
			return(FALSE);
	}
    return(TRUE);
}
BOOL CALLBACK BuildBatStep2SectionProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam){
	int nIndex, nStrlen;
	char* szText;
    switch( uMsg )
 	{
 		case WM_INITDIALOG:
 			break;
		case WM_SHOWWINDOW:
			break;
 		case WM_COMMAND :
			switch( LOWORD( wParam )){
			
			case IDCANCEL:
    			EndDialog(hDlg, TRUE);
    			return (TRUE);
			}
			break;
 		default :	
			return(FALSE);
	}
    return(TRUE);
}
BOOL CALLBACK BuildBatStep2IfProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam){
	switch( uMsg )
 	{
 		case WM_INITDIALOG:
			initializeBuildBatIf( hDlg,  uMsg,  wParam,  lParam );
 			break;
		case WM_SHOWWINDOW:
			break;
 		case WM_COMMAND :
			switch( LOWORD( wParam )){
			case IDOK:
				break;
			case IDCANCEL:
    			EndDialog(hDlg, TRUE);
    			return (TRUE);
			}
			break;
 		default :	
			return(FALSE);
	}
    return(TRUE);
}
BOOL CALLBACK BuildBatStep2ForProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam){
	switch( uMsg )
 	{
 		case WM_INITDIALOG:
			initializeBuildBatFor( hDlg,  uMsg,  wParam,  lParam );
 			break;
		case WM_SHOWWINDOW:
			break;
 		case WM_COMMAND :
			switch( LOWORD( wParam )){
			case IDOK:
				break;
			case IDCANCEL:
    			EndDialog(hDlg, TRUE);
    			return (TRUE);
			}
			break;
 		default :	
			return(FALSE);
	}
    return(TRUE);
}
