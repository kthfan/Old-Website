
#ifndef _MAIN
#define _MAIN

/*
#include <windows.h>
//#include <wingdi.h>
#include <ShellAPI.h>
#include <string.h>
#include <stdio.h>
#include "Resource.h"
#include <direct.h>
#include <time.h>
#include <commctrl.h>
*/
#ifndef _AT_LIB
#include "AT_lib.h"
#endif //_AT_LIB
#ifndef _SOLVE_CONFIG
#include "solve_config.h"
#endif //_SOLVE_CONFIG
#ifndef _WIN_PROCEDURE
#include "win_procedure.h"
#endif //_WIN_PROCEDURE


#define MAX_COMPILER_STR_LENGTH 256
#define ITEM_ALIGN_TOP 10
#define ITEM_ALIGN_LEFT 10
#define ITEM_SEP_HOR 20
#define ITEM_SEP_VER 30
#define TEXT_HEIGHT 20
#define ITEM_CMD_WIDTH 60
#define CMD_ALIGN_TOP (ITEM_ALIGN_TOP+70)
#define DROP_ALIGN_TOP (CMD_ALIGN_TOP+100)
#define ITEM_COMR_WIDTH 180
#define ITEM_FILE_LIST_WIDTH 300
#define ITEM_FILE_LIST_HEIGHT 150
#define CONFIG_FILE_NAME "AT.conf"
#define COMRINFO_ATTR_NUM 4
#define LOG_FILE_NAME "AT.log"

#pragma comment (lib,"user32.lib")
#pragma comment (lib,"gdi32.lib")
#pragma comment (lib,"Shell32.lib")
#pragma comment (lib,"Comdlg32.lib")
#pragma comment(lib, "comctl32.lib")

typedef struct _StringArray{
	char** array;
	int length;
}StringArray;

//solve_config.h
extern VOID bulid_compiler_list();
extern VOID rebulid_compiler_list();
extern BOOL remove_compiler_list(char* item);
extern BOOL load_config();
extern BOOL save_config();
extern BOOL check_config();
extern VOID buildDlgCompilerList();
//win_procedure.h
extern LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);
extern BOOL CALLBACK Query4FileDlgProc(HWND, UINT, WPARAM, LPARAM);
extern BOOL CALLBACK ConfirmDlgProc(HWND, UINT, WPARAM, LPARAM);
extern BOOL CALLBACK SettingCompilerDlgProc(HWND, UINT, WPARAM, LPARAM);
extern BOOL CALLBACK ManageCompilerDlgProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK CmdLineProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
extern LRESULT userMenu( HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam );
extern void cmdThread(char* buf);
//AT_lib.h
extern int file_exists(char* filename);
extern char* getEditText(HWND hEdit);
extern VOID insertComboBoxText(HWND hComboBox, char* szText, int nIndex);
extern VOID insertListBoxText(HWND hListBox, char* szText, int nIndex);
extern VOID setListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
extern VOID insertListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen, int nIndex);
extern VOID appendListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
extern VOID setComboBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
extern VOID insertComboBoxTexts(HWND hComboBox, char** lpTexts, int nTestsLen, int nIndex);
extern VOID appendComboBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
extern int check_multiple_files_exists(char** lpFileList, int nFileListLen);
extern char* getDirName(char* filename);
extern char* getExceptDirName(char* filename);
extern char* fileList2Str(char** lpFileList, int nFileListLen);
extern char* getSurroundQuotesFileList(char** lpFileList, int nFileListLen);
extern char* getSurroundQuotes(char* szFile);
extern BOOL updateListBoxViewWidth(HWND hListBox);
extern int calcLBItemWidth(HWND hLB, char* Text);
extern void freeArray(void** ptr, int len);
extern char* getStrFromListBox(HWND hListBox, int nIndex);
extern char** getStrArrayFromListBox(HWND hListBox, int nListBoxLen);
extern int getDuplicateStr(char** lpArrayMain, char** lpArrayVice,int nArrayMainLen, int nArrayViceLen, int nStartIndex);
extern char** toNonEmptyStrArray(char** lpArray, int nArrayLen);
extern int getNonEmptyStrArrayCount(char** lpArray, int nArrayLen);
extern char** catStrArray(char** lpArray1, char** lpArray2,int nArray1Len, int nArray2Len);
extern int isStrArrayDuplicate(char** lpArray, int nArrayLen);
extern char** copyStrArray(char** lpArrayDist, char** lpArraySrc, int nArrayLen);

//main.h
void update_opts(void);
//void asm_file(char* filename,char* dist_file,HWND hwnd);
//void check_dist_asm(char* filename,HWND hwnd);
int getEditText4Path(HWND hEdit,int maxLen,char* dist);
void solve_fo_ext(char* filename,char* dist);
void check_asm_success(HWND hwnd);
void create_tmp_exe(HWND hwnd);
char* toATPathFileName(char* filename);
VOID compile_multiple_files();
char** get_multiple_files_from_list(int nFileListlen);
VOID asm_multiple_files(char** lpFileList, int nFileListLen);
#endif //_MAIN



