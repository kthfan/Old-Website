
#ifndef _WIN_PROCEDURE
#include "win_procedure.h"
#endif //_WIN_PROCEDURE

//main.h
extern CompilerInfo* ptrSelListBox;
extern CompilerInfo* complier_array;
extern CompilerInfo* tmp_complier_array;
extern StringArray fileListArray;


LRESULT userMenu( HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam ){
	int ItemIndex;
	char* szBuf;
	switch( LOWORD( wParam )) {
		case IDM_Compiler:
			DialogBox(g_hInst, "ManageCompiler", hwnd, (DLGPROC) ManageCompilerDlgProc);
			break;
		case IDM_BuildBat:
			DialogBox(g_hInst, "BuildBat", hwnd, (DLGPROC) BuildBatDlgProc);
			break;
		case IDC_CompileBn:
			_getcwd( loc_dir, MAX_PATH );
			chdir(AT_PWD);
			compile_multiple_files();
			chdir(loc_dir);
			break;
		case IDC_EditCodeBn:
			HANDLE hEditorThread ;
			DWORD dwEditorThreadID ;
			char* szEditFile;
			char* szATEeditor;
			int nSize;
			szATEeditor = toATPathFileName("editor\\notepad++\\notepad++.exe");
			ItemIndex = SendMessage(hFileList, (UINT) LB_GETCURSEL, (WPARAM) 0, (LPARAM) 0);
			if(ItemIndex == LB_ERR){
				MessageBox(g_hwnd,"No file selected.","Note",MB_OK);
			}else if(!file_exists(szATEeditor)){
				MessageBox(g_hwnd,"Editor path not exists.","Error",MB_OK);
			}else{
				STARTUPINFO si;
				PROCESS_INFORMATION pi;
				ZeroMemory( &si, sizeof(si) );
				si.cb = sizeof(si);
				ZeroMemory( &pi, sizeof(pi) );
				//
				szEditFile = getStrFromListBox(hFileList, ItemIndex);
				nSize = (strlen(szATEeditor) + strlen(szEditFile) + 11)*sizeof(char);
				szBuf = (char*) malloc(nSize);
				ZeroMemory(szBuf, nSize);
				sprintf(szBuf, "\"%s\" \"%s\"", szATEeditor, szEditFile);
				if( !CreateProcess( NULL,szBuf,NULL, NULL, FALSE, 0,NULL,NULL, &si,&pi ) ) 
					MessageBox(g_hwnd,"Unable to open the editor.","Error",MB_OK);
				
				free(szEditFile);
				
			}
			free(szATEeditor);
			break;
		case IDC_DelFileBn:
			ItemIndex = SendMessage(hFileList, (UINT) LB_GETCURSEL, (WPARAM) 0, (LPARAM) 0);
			SendMessage(hFileList,(UINT) LB_DELETESTRING,(WPARAM) ItemIndex,(LPARAM) 0);
			SendMessage(hFileList, LB_SETCURSEL, ItemIndex-1<0?0:ItemIndex-1 , 0);
			break;
		case IDC_ClearFileBn:
			SendMessage(hFileList, LB_RESETCONTENT, 0, 0);
			break;
		case IDC_OpenFileBn:
			//chdir(PWD);
			_getcwd( loc_dir, MAX_PATH );
			ZeroMemory(file_name_buf,MAX_PATH);
			OPENFILENAME ofn;
			ZeroMemory(&ofn, sizeof(OPENFILENAME));
       		ofn.lStructSize = sizeof(OPENFILENAME);
       		ofn.hwndOwner = hwnd;
       		ofn.lpstrFile = file_name_buf;
        	ofn.nMaxFile = _MAX_PATH;
       		ofn.lpstrFilter = "All\0*.*\0asm\0*.asm\0\0";
       		ofn.nFilterIndex = 0;
			ofn.lpstrInitialDir = loc_dir;
       		ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT | OFN_EXPLORER;
        	if (GetOpenFileName(&ofn) == TRUE) {
        		char** lpFilesList;
        		int nFilesLen, i;
				ItemIndex = SendMessage(hFileList, (UINT) LB_GETCURSEL, (WPARAM) 0, (LPARAM) 0);
        		nFilesLen = getFilesLenFromOfn(&ofn);
        		lpFilesList = getFilesNameFromOfn(&ofn, nFilesLen);
        		//appendListBoxTexts(hFileList, lpFilesList, nFilesLen);
				insertListBoxTexts(hFileList, lpFilesList, nFilesLen, ItemIndex);
        		//SendMessage(hFileList,(UINT) LB_ADDSTRING, (WPARAM) 0, (LPARAM) file_name_buf);
        		//SendMessage(hFileList, LB_SETCURSEL, 0, 0);
        		freeArray((void**) lpFilesList, nFilesLen);
        		//updateListBoxViewWidth(hFileList);
			}
			break;
		default:
			return DefWindowProc( hwnd, uMessage, wParam, lParam ) ;
	}
	return 0;
}
LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	
	HDROP hDropInfo;
	
	switch (message)                  /* handle the messages */
	{
	case WM_CREATE:
		g_hwnd = hwnd;
		srand( time(NULL) );
		_getcwd( AT_PWD, MAX_PATH );
		CreateWindowEx(0,"static",TEXT("compiler"),WS_CHILD | WS_VISIBLE, ITEM_ALIGN_LEFT, ITEM_ALIGN_TOP , ITEM_COMR_WIDTH, TEXT_HEIGHT
				,hwnd,(HMENU)IDC_TXT1,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		CreateWindowEx(0,"static",TEXT("input files"),WS_CHILD | WS_VISIBLE, ITEM_ALIGN_LEFT, CMD_ALIGN_TOP+TEXT_HEIGHT*2, 100, TEXT_HEIGHT
				,hwnd,(HMENU)IDC_TXT2,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		hFileList = CreateWindowEx(0,"ListBox",TEXT(""),WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | LBS_HASSTRINGS | LBS_NOTIFY
				,ITEM_ALIGN_LEFT, CMD_ALIGN_TOP+TEXT_HEIGHT*3, ITEM_FILE_LIST_WIDTH, ITEM_FILE_LIST_HEIGHT
				,hwnd,(HMENU)IDC_FileList,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		hCompileBn = CreateWindowEx(0,TEXT("Button"),TEXT("Compile"),WS_CHILD|WS_VISIBLE,
                   APP_WIDTH-120 , APP_HEIGHT-100, 80, TEXT_HEIGHT,
				   hwnd,(HMENU)IDC_CompileBn,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		hEditCodeBn = CreateWindowEx(0,TEXT("Button"),TEXT("Edit"),WS_CHILD|WS_VISIBLE,
                   APP_WIDTH-180 , APP_HEIGHT-100, 50, TEXT_HEIGHT,
				   hwnd,(HMENU)IDC_EditCodeBn,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		hDelFileBn = CreateWindowEx(0,TEXT("Button"),TEXT("Remove"),WS_CHILD|WS_VISIBLE,
                   ITEM_FILE_LIST_WIDTH+2*ITEM_ALIGN_LEFT , CMD_ALIGN_TOP+TEXT_HEIGHT*5, 80, TEXT_HEIGHT,
				   hwnd,(HMENU)IDC_DelFileBn,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		hClearFileBn = CreateWindowEx(0,TEXT("Button"),TEXT("Clear"),WS_CHILD|WS_VISIBLE,
                   ITEM_FILE_LIST_WIDTH+2*ITEM_ALIGN_LEFT , CMD_ALIGN_TOP+TEXT_HEIGHT*7, 80, TEXT_HEIGHT,
				   hwnd,(HMENU)IDC_ClearFileBn,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		CreateWindowEx(0,"static",TEXT("Drop File Here"),WS_CHILD | WS_VISIBLE, ITEM_ALIGN_LEFT*2+ITEM_COMR_WIDTH, ITEM_ALIGN_TOP,45,50
				,hwnd,(HMENU)IDC_DropHint,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		hCompilerComboBox = CreateWindowEx(0,"COMBOBOX",TEXT(""),CBS_DROPDOWNLIST | WS_CHILD | WS_VISIBLE | CBS_AUTOHSCROLL| WS_HSCROLL | WS_VSCROLL
				,ITEM_ALIGN_LEFT,ITEM_ALIGN_TOP+TEXT_HEIGHT,ITEM_COMR_WIDTH,210,
				hwnd,(HMENU)IDC_BIT,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		//hAsmTypeComboBox = CreateWindowEx(0,"COMBOBOX",TEXT(""),CBS_DROPDOWNLIST | WS_CHILD | WS_VISIBLE,ITEM_ALIGN_LEFT+ITEM_BIT_WIDTH+ITEM_SEP_HOR,ITEM_ALIGN_TOP+TEXT_HEIGHT,120,70,
		//		hwnd,(HMENU)IDC_ASM,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		hOpenBn = CreateWindowEx(0,TEXT("Button"),TEXT("Browse File"),WS_CHILD|WS_VISIBLE,
                   ITEM_FILE_LIST_WIDTH+2*ITEM_ALIGN_LEFT, CMD_ALIGN_TOP+TEXT_HEIGHT*3, 100,TEXT_HEIGHT,
				   hwnd,(HMENU)IDC_OpenFileBn,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		hCmdEdit = CreateWindowEx(0,TEXT("Edit"),TEXT(""),WS_VISIBLE|WS_CHILD|ES_AUTOHSCROLL,ITEM_ALIGN_LEFT+ITEM_CMD_WIDTH+10,CMD_ALIGN_TOP,250,20,hwnd,(HMENU)IDC_CmdEdit,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		CreateWindowEx(0,"static",TEXT("cmd line:"),WS_CHILD | WS_VISIBLE,ITEM_ALIGN_LEFT,CMD_ALIGN_TOP,ITEM_CMD_WIDTH,20,hwnd,(HMENU)IDC_TXT10,((LPCREATESTRUCT) lParam) -> hInstance,(LPVOID)NULL);
		bulid_compiler_list();
		DragAcceptFiles(hwnd,TRUE);
		lpCmdEditHwndProc = (WNDPROC) SetWindowLongPtr(hCmdEdit, -4, (LONG_PTR)&CmdLineProc);
		return 0;

	case WM_DROPFILES:
		{
			int uNumFiles, i, nSelectedIndex;
            hDropInfo = (HDROP) wParam;
			nSelectedIndex = SendMessage(hFileList, LB_GETCURSEL, 0, 0);
            uNumFiles = DragQueryFile ( hDropInfo, -1, NULL, 0 );
			if(nSelectedIndex==-1) nSelectedIndex = 0;
			for (i = 0; i < uNumFiles; i++ ){
				ZeroMemory(file_name_buf,MAX_PATH);
        		if ( DragQueryFile ( hDropInfo, i, file_name_buf, MAX_PATH ) > 0 ){
					if(i==0){
						char* szDir = getDirName(file_name_buf);
						chdir(szDir);
						free(szDir);
					} 
            		SendMessage(hFileList,(UINT) LB_INSERTSTRING , (WPARAM) nSelectedIndex+i, (LPARAM) file_name_buf);
            	}
        	}
			//chdir(PWD);
			updateListBoxViewWidth(hFileList);
			SendMessage(hFileList, LB_SETCURSEL, nSelectedIndex , 0);
			break;
		}
	case WM_COMMAND:
		userMenu( hwnd, message, wParam, lParam ) ;
		break;
	case WM_DESTROY:
		PostQuitMessage (0);       /* send a WM_QUIT to the message queue */
		break;
	default:                      /* for messages that we don't deal with */
		return DefWindowProc (hwnd, message, wParam, lParam);

	}
	return 0;
}
BOOL CALLBACK Query4FileDlgProc( HWND hDlg, UINT uMsg, 
                   WPARAM wParam, LPARAM lParam )
{
	int len;
	char* buf;
 	switch( uMsg )
 	{
  		case WM_INITDIALOG :
  			hREdit = GetDlgItem(hDlg,IDC_REdit);
			hOBn = GetDlgItem(hDlg,IDC_OBN);
			hRBn = GetDlgItem(hDlg,IDC_RBN);
			hQBn = GetDlgItem(hDlg,IDC_QBN);
			len = sizeof(char)*(strlen(exe_name_buf)+19);
			buf = (char*) malloc(len);
			ZeroMemory(buf,len);
			sprintf(buf,"\"%s\" already exists.",exe_name_buf);
			SetDlgItemText(hDlg,IDC_TXT4,buf);
			free(buf);
			SetDlgItemText(hDlg,IDC_TXT5,"Please choose one of the following solutions.");
            
		return (TRUE);

  		case WM_COMMAND :
   		switch( LOWORD( wParam ) )
   			{
			case IDC_OBN:
				remove_old = TRUE;
				EndDialog(hDlg, TRUE);
    			return (TRUE);
			case IDC_RBN:
				if(getEditText4Path(hREdit,MAX_PATH,exe_name_buf)){
					MessageBox(hDlg, "Invalid file name.", "Error", MB_OK);
					return (TRUE);
				}
				len = (strlen(exe_name_buf)+4)*sizeof(char);
				buf = (char*) malloc(len);
				ZeroMemory(buf, len);
				sprintf(buf,"%s.exe",exe_name_buf);
				if(file_exists(exe_name_buf) || file_exists(buf)){
					int buf_len = sizeof(char)*(strlen(exe_name_buf)+24);
					char* buf = (char*) malloc (buf_len);
					ZeroMemory(buf,buf_len);
					sprintf(buf,"File name \"%s\" still exists.",exe_name_buf);
					MessageBox(hDlg, buf, "Note", MB_OK);
					free(buf);
				}else {
					EndDialog(hDlg, TRUE);
				}
				free(buf);
				return (TRUE);
			case IDC_QBN:
    		case IDCANCEL:
    			ZeroMemory(exe_name_buf,1);
    			EndDialog(hDlg, TRUE);
    			return (TRUE);
   			}
   			
   		break;

  	
  	default :
   		return(FALSE);
 	}

 	return(TRUE);
}
BOOL CALLBACK ConfirmDlgProc( HWND hDlg, UINT uMsg, 
                   WPARAM wParam, LPARAM lParam )
{
	int len;
	char* buf;
	HWND hComFileList;
	CompilerInfo opt;
 	switch( uMsg )
 	{
  		case WM_INITDIALOG:
  			opt = findCompilerInfo(szSelectOpt)[0];
  			
  			hComFileList = GetDlgItem(hDlg,IDC_ConfirmFilesList);
  			setListBoxTexts(hComFileList, fileListArray.array, fileListArray.length);
  			/*
  			SendMessage(hCompilerComboBox,(UINT) LB_ADDSTRING,(WPARAM) 0,(LPARAM) complier_array[k].name); 
  			len = sizeof(char)*(strlen(file_name_buf)+8);
			buf = (char*) malloc(len);
			ZeroMemory(buf,len);
			sprintf(buf,"Input: %s",file_name_buf);
			SetDlgItemText(hDlg,IDC_TXT6,buf);
			free(buf);
			*/
			len = sizeof(char)*(strlen(exe_name_buf)+9);
			buf = (char*) malloc(len);
			ZeroMemory(buf,len);
			sprintf(buf,"Output: %s",exe_name_buf);
			SetDlgItemText(hDlg,IDC_TXT7,buf);
			free(buf);
			
			len = sizeof(char)*(strlen(opt.path)+7);
			buf = (char*) malloc(len);
			ZeroMemory(buf,len);
			sprintf(buf,"Path: %s",opt.path);
			SetDlgItemText(hDlg,IDC_TXT8,buf);
			free(buf);
			
			len = sizeof(char)*(strlen(opt.additional)+13);
			buf = (char*) malloc(len);
			ZeroMemory(buf,len);
			sprintf(buf,"Additional: %s",opt.additional);
			SetDlgItemText(hDlg,IDC_TXT9,buf);
			free(buf);
			
			return (TRUE);
  		case WM_COMMAND :
   			switch( LOWORD( wParam ) )
   			{
				case IDOK:
					//if (remove_old && remove(exe_name_buf) != 0){
					//	MessageBox(hDlg, "Unable to overwrite the file.", "Error", MB_OK);
					//	ZeroMemory(exe_name_buf,1);
					//}
					if(remove_old){
						create_tmp_exe(hDlg);
					}
					//remove_old = FALSE;
					EndDialog(hDlg, TRUE);
					break;
				case IDCANCEL:
					ZeroMemory(exe_name_buf,1);
    				EndDialog(hDlg, TRUE);
					break;
			}
			break;
		default :	
   		return(FALSE);
	}
	return(TRUE);
}
BOOL CALLBACK SettingCompilerDlgProc( HWND hDlg, UINT uMsg, 
                   WPARAM wParam, LPARAM lParam )
{
	static HWND h_CN_Edit, h_CP_Edit, h_CF_Edit, h_CA_Edit, h_CF_CB;
	switch( uMsg )
 	{
 		case WM_INITDIALOG:
 			h_CN_Edit = GetDlgItem(hDlg,IDC_CN_Edit);
 			h_CP_Edit = GetDlgItem(hDlg,IDC_CP_Edit);
 			h_CF_Edit = GetDlgItem(hDlg,IDC_CF_Edit);
 			h_CA_Edit = GetDlgItem(hDlg,IDC_CA_Edit);
 			h_CF_CB = GetDlgItem(hDlg,IDC_CF_CB);
 			break;
 		case WM_SHOWWINDOW:
 			if(ptrSelListBox!=NULL){
 				SetWindowTextA(h_CN_Edit,ptrSelListBox->name);
 				SetWindowTextA(h_CP_Edit,ptrSelListBox->path);
 				if(ptrSelListBox->fileout[0]==FILE_OUT_NO_ARG) SendMessage(h_CF_CB, BM_SETCHECK, BST_CHECKED, 0);
 				else SetWindowTextA(h_CF_Edit,ptrSelListBox->fileout);
 				SetWindowTextA(h_CA_Edit,ptrSelListBox->additional);
 				
			}
 			break;
 		case WM_COMMAND :
   			switch( LOWORD( wParam ) )
   			{
   				case IDC_CP_BN:
   					
   					char sz_ComrPath[MAX_PATH];
   					OPENFILENAME ofn;
					ZeroMemory(&ofn, sizeof(OPENFILENAME));
       				ofn.lStructSize = sizeof(OPENFILENAME);
       				ofn.hwndOwner = g_hwnd;
       				ofn.lpstrFile = sz_ComrPath;
        			ofn.nMaxFile = _MAX_PATH;
       				ofn.lpstrFile[0] = '\0';
       				ofn.nFilterIndex = 0;
       				ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_EXPLORER;
       				
        			if (GetOpenFileName(&ofn) == TRUE) SetWindowTextA(h_CP_Edit,sz_ComrPath);
        			chdir(AT_PWD);
   					break;
				case IDOK:
					CompilerInfo* info;
					info = (CompilerInfo*) malloc(sizeof(CompilerInfo));
					ZeroMemory(info,sizeof(CompilerInfo));
					info->name = getEditText(h_CN_Edit);
					info->path = getEditText(h_CP_Edit);
					if(SendMessage(h_CF_CB, BM_GETCHECK, 0, 0)) info->fileout = "\1";
					else info->fileout = getEditText(h_CF_Edit);
					info->additional = getEditText(h_CA_Edit);
					add_compiler_list(info);
					free(info);
					EndDialog(hDlg, TRUE);
					break;
				case IDCANCEL:
					
    				EndDialog(hDlg, TRUE);
					break;
			}
			break;
 		default :	
		return(FALSE);
	}
	return(TRUE);
}
BOOL CALLBACK ManageCompilerDlgProc( HWND hDlg, UINT uMsg, 
                   WPARAM wParam, LPARAM lParam ){
    static HWND h_MCA_BN, h_MCS_BN, h_MCD_BN;
    int ItemIndex;
    switch( uMsg )
 	{
 		case WM_INITDIALOG:
 			h_MCA_BN = GetDlgItem(hDlg,IDC_MCA_BN);
 			h_MCS_BN = GetDlgItem(hDlg,IDC_MCS_BN);
 			h_MCD_BN = GetDlgItem(hDlg,IDC_MCD_BN);
 			hMaCompilerList = GetDlgItem(hDlg,IDC_MC_List);
 			hManageCompilerDlg = hDlg;
 			buildDlgCompilerList();
 			tmp_complier_array = copy_complier_array();
 			tmp_complier_len = complier_len;
 			break;
 		case WM_COMMAND :
   			switch( LOWORD( wParam ) )
   			{
   				case IDC_MCA_BN:
   					ptrSelListBox = NULL;
   					DialogBox(g_hInst, "SettingCompiler", hDlg, (DLGPROC) SettingCompilerDlgProc);
   					break;
   				case IDC_MCS_BN:
					ItemIndex = SendMessage(hMaCompilerList, (UINT) LB_GETCURSEL, (WPARAM) 0, (LPARAM) 0);
    				SendMessage(hMaCompilerList, (UINT) LB_GETTEXT, (WPARAM) ItemIndex, (LPARAM) szSelectOpt);
    				ptrSelListBox = findCompilerInfo(szSelectOpt);
    				DialogBox(g_hInst, "SettingCompiler", hDlg, (DLGPROC) SettingCompilerDlgProc);
   					break;
   				case IDC_MCD_BN:
					ItemIndex = SendMessage(hMaCompilerList, (UINT) LB_GETCURSEL, (WPARAM) 0, (LPARAM) 0);
    				SendMessage(hMaCompilerList, (UINT) LB_GETTEXT, (WPARAM) ItemIndex, (LPARAM) szSelectOpt);
    				remove_compiler_list(szSelectOpt);
   					break;
				case IDOK:
					free(tmp_complier_array);
					hManageCompilerDlg = NULL;
					if(!save_config())
						MessageBox(hDlg,"Unable save config.","Error",MB_OK);
					EndDialog(hDlg, TRUE);
					break;
				case IDCANCEL:
					complier_len = tmp_complier_len;
					free(complier_array);
					complier_array = tmp_complier_array;
					hManageCompilerDlg = NULL;
					rebulid_compiler_list();
    				EndDialog(hDlg, TRUE);
					break;
			}
 		default :	
		return(FALSE);
	}
    return(TRUE);
}
BOOL CALLBACK BuildBatDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam){
    switch( uMsg )
 	{
 		case WM_INITDIALOG:
			hBuildBatDlg = hDlg;
 			initializeBuildBatGUI(hDlg);
 			break;
		case WM_NOTIFY:
			return onTabNotify(hBuildBatTab, lParam);
		case WM_SHOWWINDOW:
			break;
 		case WM_COMMAND :
			return buildBatUserMenu( hDlg, uMsg, wParam, lParam );
 		default :	
			return(FALSE);
	}
    return(TRUE);
}
LRESULT CALLBACK CmdLineProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam){
	if( (uMsg == WM_KEYDOWN) && (wParam == VK_RETURN) )
    {
    	HANDLE hThread ;
		DWORD threadID ;
		char* buf;
		int org_len = GetWindowTextLength(hCmdEdit);
		int buf_size = (org_len+10)*sizeof(char);
   	 	buf = (char*) malloc( buf_size);
		ZeroMemory(buf, buf_size);
		GetWindowText(hCmdEdit, &buf[0], org_len+1);
		if(org_len>3 && buf[0]=='c' && buf[1]=='d' && buf[2]==' '){
			if(chdir(buf+3) == 0){
				ZeroMemory(buf, buf_size);
				strcpy(buf,"cd & pause");
			}else{
				ZeroMemory(buf, buf_size);
				strcpy(buf,"echo Error in cd. & pause");
			}
			hThread = CreateThread( 0, 0, (LPTHREAD_START_ROUTINE)cmdThread,(VOID* ) buf, 0, &threadID ) ;
		}else{
			strcat(buf," & pause");
			hThread = CreateThread( 0, 0, (LPTHREAD_START_ROUTINE)cmdThread,(VOID* ) buf, 0, &threadID ) ;
		}
		SetWindowTextA(hCmdEdit,"");
		
    }
    return CallWindowProc(lpCmdEditHwndProc, hwnd, uMsg, wParam, lParam);
}
void cmdThread(char* buf){
	system(buf);
	free(buf);
}
int getFilesLenFromOfn(OPENFILENAME* ofn){
	char* lpFile;
	char* lpCurFile;
	int i;
	lpFile = ofn->lpstrFile;
	lpCurFile = lpFile+ofn->nFileOffset;
	i=0;
	while(lpCurFile && *lpCurFile){
        lpCurFile += strlen(lpCurFile)+1;
        i++;
    }
    if(i==0) return 1;
    return i;
}
char** getFilesNameFromOfn(OPENFILENAME* ofn, int nFilesLen){
	char* lpFile;
	char* lpCurFile;
	char** lpRes;
	int nPathLen, nTempLen;
	int i;
	lpFile = ofn->lpstrFile;
	lpCurFile = lpFile+ofn->nFileOffset;
	lpRes = (char**) malloc(sizeof(char*)*nFilesLen);
	nPathLen = strlen(lpFile);
	//pCurFile += strlen(lpCurFile)+1;
	if(nFilesLen==1){
		nTempLen = nPathLen + 1;
		lpRes[0] = (char*) malloc(sizeof(char)*nTempLen);
		ZeroMemory(lpRes[0],sizeof(char)*nTempLen);
		strcpy(lpRes[0], lpFile);
		return lpRes;
	}
	for(i=0;i<nFilesLen;i++){
		nTempLen = strlen(lpCurFile) + nPathLen + 2;
		lpRes[i] = (char*) malloc(sizeof(char)*nTempLen);
		ZeroMemory(lpRes[i],sizeof(char)*nTempLen);
		strcpy(lpRes[i], lpFile);
		strcat(lpRes[i], "\\");
		strcat(lpRes[i], lpCurFile);
        
        lpCurFile += strlen(lpCurFile)+1;
	}
	return lpRes;
}
