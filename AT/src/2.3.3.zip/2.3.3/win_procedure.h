
#ifndef _WIN_PROCEDURE
#define _WIN_PROCEDURE

#ifndef _MAIN
#include "main.h"
#endif
#ifndef _AT_LIB
#include "AT_lib.h"
#endif //_AT_LIB
#ifndef _BUILD_BAT_GUI
#include "build_bat_gui.h"
#endif 
#ifndef _WINDOWS_
#include <windows.h>
#endif


LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK Query4FileDlgProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK ConfirmDlgProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK SettingCompilerDlgProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK ManageCompilerDlgProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK BuildBatDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK CmdLineProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
LRESULT userMenu( HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam );
void cmdThread(char* buf);
char** getFilesNameFromOfn(OPENFILENAME* ofn, int nFilesLen);
int getFilesLenFromOfn(OPENFILENAME* ofn);


//main.h

extern VOID compile_multiple_files();
extern char* toATPathFileName(char* filename);
extern unsigned int complier_len;
extern unsigned int tmp_complier_len;
extern HINSTANCE g_hInst;
extern HWND hQuery4FileDlg;
extern HWND hConfirmDlg;
extern WNDPROC lpCmdEditHwndProc;
extern char szSelectOpt[];
extern HWND hCompilerComboBox, hMaCompilerList, hEditCodeBn
	,hOBn, hRBn, hQBn ,hREdit ,hOpenBn ,hCmdEdit
	, hManageCompilerDlg, hFileList, hCompileBn
	, hDelFileBn, hClearFileBn;
extern char file_name_buf[MAX_PATH];
extern char exe_name_buf[MAX_PATH];
extern char tmp_exe_buf[MAX_PATH];
extern char AT_PWD[MAX_PATH];
extern char loc_dir[MAX_PATH];
extern BOOL remove_old;
extern HWND g_hwnd;
//AT_lib.h
extern int file_exists(char* filename);
extern char* getDirName(char* filename);
extern char* getStrFromListBox(HWND hListBox, int nIndex);
extern VOID setListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
extern VOID appendListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen);
extern VOID insertListBoxTexts(HWND hListBox, char** lpTexts, int nTestsLen, int nIndex);
extern BOOL updateListBoxViewWidth(HWND hListBox);
extern void freeArray(void** ptr, int len);
// build_bat_gui.h
extern VOID initializeBuildBatGUI(HWND hwndParent);
extern BOOL onTabNotify(HWND hwndTab, LPARAM lParam);
extern BOOL buildBatUserMenu( HWND hDlg, UINT uMessage, WPARAM wParam, LPARAM lParam );


#endif //_WIN_PROCEDURE


